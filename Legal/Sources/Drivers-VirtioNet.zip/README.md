﻿# VIRTNET.R4D

`VIRTNET.R4D` is an independent R4OS driver implemented in Zig.

## Package

- Version: `0.1.3`
- Image target: `/R4OS/DRIVERS/VIRTNET.R4D`
- Image scope: `slim`
- Canonical project manifest: `module.R4MF`

The manifest is the single source of truth for the artifact, imports, image
target, and package metadata.

The read-to-clear interrupt handler performs one ordered RX used-index check.
Only a queue cause with pending RX entries publishes DriverApi v23 work;
configuration-only and TX-only interrupts do not enter the RX protocol path.
The `net-rx` task drains descriptors and retains the current used entry while
the bounded common queue is full.

NetBackend v2 offers RX L4 checksum validation only when the virtio device
accepted `VIRTIO_NET_F_GUEST_CSUM`. DriverApi v24 confirms the selection.
`DATA_VALID` is then propagated to NetUdp/NetTcp; `NEEDS_CSUM` is completed
in place and still software-verified. Unknown or rejected metadata retains
the canonical flat frame and all other offloads remain disabled.

## Build

On Windows:

    Build.bat

On Linux or macOS:

    ./Build.sh

The build starters resolve the current local R4OS dependency checkouts through
`Settings.R4S`. The URL and hash entries in `build.zig.zon` record the
last verified standalone dependency identities; workspace builds use the
mapped local checkouts.

## Documentation

Detailed German technical notes from the migration are preserved in
`DOCUMENTATION.de.txt`. Source-transfer provenance is recorded in
`PROVENANCE.txt`.

## License

Original R4OS material is licensed under Apache License 2.0. See `LICENSE`
and `NOTICE`. Any repository-specific external material is documented in
`THIRD_PARTY_NOTICES.md`.
