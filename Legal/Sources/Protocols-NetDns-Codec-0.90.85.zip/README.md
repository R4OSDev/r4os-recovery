﻿# NETDNS.R4P

`NETDNS.R4P` is an independent R4OS protocol module implemented in Zig.

## Package

- Version: `0.1.1`
- Image target: `/R4OS/PROTOCOLS/NETDNS.R4P`
- Image scope: `slim`
- Canonical project manifest: `module.R4MF`

The manifest is the single source of truth for the artifact, imports, image
target, and package metadata.

## Build

On Windows:

    Build.bat

On Linux or macOS:

    ./Build.sh

The build starters resolve the current local R4OS dependency checkouts through
`Settings.R4S`. The URL and hash entries in `build.zig.zon` record the
last verified standalone dependency identities; workspace builds use the
mapped local checkouts.

## Documentation

The source package also exports the transport-independent `address_codec`
Zig module. `DnsService` pins and reuses that complete A/AAAA answer codec.
Run `./Build.sh test` (Windows: `Build.bat test`) for its wire fixtures.
The existing R4P dispatch and artifact version remain unchanged; codec
availability alone does not advertise an IPv6 network provider.

Detailed German technical notes from the migration are preserved in
`DOCUMENTATION.de.txt`. Source-transfer provenance is recorded in
`PROVENANCE.txt`.

## License

Original R4OS material is licensed under Apache License 2.0. See `LICENSE`
and `NOTICE`. Any repository-specific external material is documented in
`THIRD_PARTY_NOTICES.md`.
