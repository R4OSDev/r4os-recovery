const std = @import("std");

// Build policy is supplied by the selected SDK, not by the frozen ABI inputs.
const RecoveryPolicy = struct {
    target: []const u8,
    optimize: std.builtin.OptimizeMode,
    cpu_features_sub: []const std.Target.x86.Feature,
    cpu_features_add: []const std.Target.x86.Feature,
    code_model: std.builtin.CodeModel,
    red_zone: bool,
    pic: bool,
    sanitize_c: std.zig.SanitizeC,
    single_threaded: bool,
    stack_check: bool,
    stack_protector: bool,
    strip_default: bool,
};

fn sdkPolicy(b: *std.Build) RecoveryPolicy {
    const path = b.option([]const u8, "sdk-build-profile-json", "SDK-selected Build.json") orelse @panic("Use Recovery/Build.ps1 with a selected SDK profile");
    const bytes = std.Io.Dir.cwd().readFileAlloc(b.graph.io, path, b.allocator, .limited(1024 * 1024)) catch @panic("Cannot read SDK build profile");
    const Document = struct { codegen: struct { recovery: RecoveryPolicy } };
    const parsed = std.json.parseFromSlice(Document, b.allocator, bytes, .{ .ignore_unknown_fields = true }) catch @panic("Invalid SDK recovery profile");
    if (!std.mem.eql(u8, parsed.value.codegen.recovery.target, "x86_64-freestanding-none")) @panic("Unsupported Recovery target");
    return parsed.value.codegen.recovery;
}

pub fn build(b: *std.Build) void {
    const profile = sdkPolicy(b);
    const RecoveryProbe = enum { none, poweroff, reboot, ram, storage, input, ui };
    const recovery_probe = b.option(RecoveryProbe, "recovery-probe", "Bounded Recovery foundation guest witness") orelse .none;
    const recovery_version_source = b.option([]const u8, "recovery-version", "Recovery release version") orelse @panic("Recovery version must be supplied by Build.ps1");
    const runtime_sha256 = b.option([]const u8, "runtime-sha256", "SHA-256 of the paired complete RAM volume") orelse "";
    const runtime_bytes = b.option(u64, "runtime-bytes", "Size of the paired complete RAM volume") orelse 0;
    if ((recovery_probe == .none or recovery_probe == .ram or recovery_probe == .storage or recovery_probe == .input or recovery_probe == .ui) and (runtime_sha256.len != 64 or runtime_bytes == 0))
        @panic("Build the paired runtime.img through Build.ps1 before building the Recovery kernel");
    // The R4OS kernel is pinned to ReleaseSafe. Debug overflows the Zig 0.16
    // ELF linker, while the kernel must never inherit a caller optimization.
    const optimize = profile.optimize;
    const enable_exception_test = b.option(
        bool,
        "exception-test",
        "Trigger an invalid-opcode exception after loading the IDT",
    ) orelse false;
    const enable_page_fault_test = b.option(
        bool,
        "page-fault-test",
        "Trigger a page fault after paging helpers are initialized",
    ) orelse false;
    const enable_general_protection_test = b.option(
        bool,
        "general-protection-test",
        "Trigger a general-protection fault after loading the IDT",
    ) orelse false;
    const enable_crash_screen_test = b.option(
        bool,
        "crash-screen-test",
        "Render the crash screen after the boot framebuffer is initialized",
    ) orelse false;
    const enable_kernel_fatal_test = b.option(
        bool,
        "kernel-fatal-test",
        "Trigger a central KernelFatal crash after the boot framebuffer is initialized",
    ) orelse false;
    const enable_zig_panic_test = b.option(
        bool,
        "zig-panic-test",
        "Trigger a Zig panic through the central crash path after the boot framebuffer is initialized",
    ) orelse false;
    const enable_com1_debug = b.option(
        bool,
        "com1-debug",
        "Enable COM1 serial output for early kernel debug logs",
    ) orelse true;
    const enable_metrics = b.option(
        bool,
        "metrics",
        "Enable lock/starvation metrics scans",
    ) orelse true;
    const force_x2apic = b.option(
        bool,
        "force-x2apic",
        "Force-enable x2APIC MSR mode when supported",
    ) orelse false;
    const stack_guard_test = b.option(
        bool,
        "stack-guard-test",
        "Spawn a kernel thread that intentionally overflows its stack",
    ) orelse false;
    const boot_selftests = b.option(
        bool,
        "boot-selftests",
        "Run invasive heap, page-table, scheduler, and sync selftests during boot",
    ) orelse false;
    const block_dispatch_selftest = b.option(
        bool,
        "block-dispatch-selftest",
        "Run controller-parallel and asynchronous block-dispatch selftests during boot",
    ) orelse false;
    const net_loss_test = b.option(
        bool,
        "net-loss-test",
        "Drop every Nth received network frame in test builds",
    ) orelse false;
    const smp_fail_ap_index = b.option(
        u32,
        "smp-fail-ap-index",
        "Diagnostic seam: leave the selected AP index offline",
    ) orelse 0xFFFF_FFFF;
    const strip_kernel = b.option(
        bool,
        "strip-kernel",
        "Strip host-only debug and symbol sections from the installed kernel ELF",
    ) orelse profile.strip_default;

    const target = b.resolveTargetQuery(.{
        .cpu_arch = .x86_64,
        .os_tag = .freestanding,
        .abi = .none,
        .cpu_features_sub = std.Target.x86.featureSet(profile.cpu_features_sub),
        .cpu_features_add = std.Target.x86.featureSet(profile.cpu_features_add),
    });

    const contract = b.dependency("r4os_contract", .{});
    const contract_kernel = b.createModule(.{
        .root_source_file = contract.path("Generated/Kernel/Zig/r4x_api_generated.zig"),
        .target = target,
        .optimize = optimize,
    });

    const kernel_mod = b.createModule(.{
        .root_source_file = b.path("recovery_main.zig"),
        .target = target,
        .optimize = optimize,
        .code_model = profile.code_model,
        .red_zone = profile.red_zone,
        .pic = profile.pic,
        .sanitize_c = profile.sanitize_c,
        .single_threaded = profile.single_threaded,
        .stack_check = profile.stack_check,
        .stack_protector = profile.stack_protector,
        .strip = strip_kernel,
    });
    const config = b.addOptions();
    config.addOption(RecoveryProbe, "recovery_probe", recovery_probe);
    config.addOption([]const u8, "recovery_version", recovery_version_source);
    config.addOption([]const u8, "runtime_sha256", runtime_sha256);
    config.addOption(u64, "runtime_bytes", runtime_bytes);
    config.addOption(bool, "enable_exception_test", enable_exception_test);
    config.addOption(bool, "enable_page_fault_test", enable_page_fault_test);
    config.addOption(bool, "enable_general_protection_test", enable_general_protection_test);
    config.addOption(bool, "enable_crash_screen_test", enable_crash_screen_test);
    config.addOption(bool, "enable_kernel_fatal_test", enable_kernel_fatal_test);
    config.addOption(bool, "enable_zig_panic_test", enable_zig_panic_test);
    config.addOption(bool, "enable_com1_debug", enable_com1_debug);
    config.addOption(bool, "enable_metrics", enable_metrics);
    config.addOption(bool, "force_x2apic", force_x2apic);
    config.addOption(bool, "enable_stack_guard_test", stack_guard_test);
    config.addOption(bool, "enable_boot_selftests", boot_selftests);
    config.addOption(bool, "enable_block_dispatch_selftest", block_dispatch_selftest);
    config.addOption(bool, "enable_net_loss_test", net_loss_test);
    config.addOption(u32, "smp_fail_ap_index", smp_fail_ap_index);
    kernel_mod.addOptions("config", config);
    kernel_mod.addImport("r4os_kernel_contract", contract_kernel);
    kernel_mod.addImport("r4os_contract2", contract.module("r4os_contract2"));
    kernel_mod.addImport("r4f_format", b.createModule(.{
        .root_source_file = b.path("kernel/font_format.zig"),
        .target = target,
        .optimize = optimize,
    }));
    const ntfs_format_mod = b.createModule(.{
        .root_source_file = b.path("Support/ntfs_format.zig"),
        .target = target,
        .optimize = optimize,
    });
    kernel_mod.addImport("ntfs_format", ntfs_format_mod);
    const ntfs_volume_mod = b.createModule(.{
        .root_source_file = b.path("Support/ntfs_volume.zig"),
        .target = target,
        .optimize = optimize,
    });
    ntfs_volume_mod.addImport("ntfs_format", ntfs_format_mod);
    kernel_mod.addImport("ntfs_volume", ntfs_volume_mod);
    kernel_mod.addImport("system_update_recovery", b.createModule(.{
        .root_source_file = b.path("Support/system_update_recovery.zig"),
        .target = target,
        .optimize = optimize,
    }));
    kernel_mod.addImport("upload_publish_claim", b.createModule(.{
        .root_source_file = b.path("Support/upload_publish_claim.zig"),
        .target = target,
        .optimize = optimize,
    }));
    kernel_mod.addImport("r4_registry_core", b.createModule(.{
        .root_source_file = b.path("Support/registry_core.zig"),
        .target = target,
        .optimize = optimize,
    }));
    kernel_mod.addAssemblyFile(b.path("arch/x86_64/cpu.S"));
    kernel_mod.addAssemblyFile(b.path("arch/x86_64/isr.S"));
    kernel_mod.addAssemblyFile(b.path("arch/x86_64/ap_trampoline.S"));

    const kernel = b.addExecutable(.{
        .name = "recovery.elf",
        .root_module = kernel_mod,
    });
    kernel.setLinkerScript(b.path("linker.ld"));
    kernel.entry = .{ .symbol_name = "kmain" };
    kernel.image_base = 0xffffffff80000000;
    b.installArtifact(kernel);

    const test_step = b.step("test", "Build the kernel and run kernel-owned host tests");
    test_step.dependOn(&kernel.step);
    const unit_tests = [_][]const u8{
        "display/console_scroll_buffer.zig",
        "display/framebuffer.zig",
        "input_controller_tests.zig",
        "audio/backend_contract.zig",
        "audio/mixer.zig",
        "driver/input/codepoint_queue.zig",
        "driver/input/key_layout.zig",
        "driver/input/hid_set1.zig",
        "driver/usb/usb_boot_timing.zig",
        "driver/usb/usb_msc_retry.zig",
        "usb_host_controller_tests.zig",
        "driver/usb/xhci_bulk_completion.zig",
        "driver/usb/xhci_endpoint_context.zig",
        "driver/usb/xhci_endpoint_recovery.zig",
        "driver/usb/xhci_event_router.zig",
        "driver/usb/xhci_ring_cycle.zig",
        "driver/usb/xhci_trb_chain.zig",
        "driver/usb/xhci_transfer_pool.zig",
        "fs/request_scope.zig",
        "fs/page_cache_batch.zig",
        "fs/page_cache_policy.zig",
        "memory/heap_policy.zig",
        "memory/owner_lock_policy.zig",
        "memory/page_batch.zig",
        "kernel/bootscreen_r4b_format.zig",
        "kernel/dma_segments.zig",
        "kernel/pci_interrupt_policy.zig",
        "kernel/driver_work_deadline.zig",
        "kernel/driver_work_queue.zig",
        "driver/com_tx_policy.zig",
        "kernel/service_ipc_queue.zig",
        "kernel/smp_policy.zig",
        "arch/x86_64/tlb_policy.zig",
        "net/backend_contract.zig",
        "net/config_writer.zig",
        "net/rx_handoff.zig",
        "net/serial_link_runtime.zig",
        "net/tcp_runtime.zig",
        "platform/monotonic_math.zig",
        "platform/pci_scan.zig",
        "program/gui_alpha8.zig",
        "program/lifecycle_retire_policy.zig",
        "program/remote_frame_state.zig",
        "program/r4x_start.zig",
        "sched/initial_stack.zig",
        "sched/wait_node.zig",
        "storage/block_dispatch.zig",
        "storage/block_split.zig",
        "storage/gpt.zig",
    };
    for (unit_tests) |path| addUnitTest(b, test_step, path);
    addFontUnitTest(b, test_step);
    addBootscreenUnitTest(b, test_step);
    addContractUnitTest(b, test_step, contract, config, "services_tests.zig");
    addLoaderTests(b, test_step, contract, config, profile.optimize);

    addProviderNegative(
        b,
        test_step,
        contract,
        "Tests/Fixture/ProviderWrongSignatureNegative.zig",
        "expected type",
    );
    addProviderNegative(
        b,
        test_step,
        contract,
        "Tests/Fixture/ProviderMissingFieldNegative.zig",
        "missing struct field",
    );
}

fn addBootscreenUnitTest(b: *std.Build, test_step: *std.Build.Step) void {
    const root = b.createModule(.{
        .root_source_file = b.path("bootscreen_tests.zig"),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    });
    root.addImport("r4f_format", b.createModule(.{
        .root_source_file = b.path("kernel/font_format.zig"),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    }));
    const tests = b.addTest(.{ .root_module = root });
    const run = b.addRunArtifact(tests);
    test_step.dependOn(&run.step);
}

fn addUnitTest(b: *std.Build, test_step: *std.Build.Step, path: []const u8) void {
    const tests = b.addTest(.{
        .root_module = b.createModule(.{
            .root_source_file = b.path(path),
            .target = b.graph.host,
            .optimize = .ReleaseSafe,
        }),
    });
    const run = b.addRunArtifact(tests);
    test_step.dependOn(&run.step);
}

fn addFontUnitTest(b: *std.Build, test_step: *std.Build.Step) void {
    const root = b.createModule(.{
        .root_source_file = b.path("font_test.zig"),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    });
    root.addImport("r4f_format", b.createModule(.{
        .root_source_file = b.path("kernel/font_format.zig"),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    }));
    const tests = b.addTest(.{ .root_module = root });
    const run = b.addRunArtifact(tests);
    test_step.dependOn(&run.step);
}

fn addContractUnitTest(
    b: *std.Build,
    test_step: *std.Build.Step,
    contract: *std.Build.Dependency,
    config: *std.Build.Step.Options,
    path: []const u8,
) void {
    const host_contract = b.createModule(.{
        .root_source_file = contract.path("Generated/Kernel/Zig/r4x_api_generated.zig"),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    });
    const root = b.createModule(.{
        .root_source_file = b.path(path),
        .target = b.graph.host,
        .optimize = .ReleaseSafe,
    });
    root.addOptions("config", config);
    root.addImport("r4os_kernel_contract", host_contract);
    root.addImport("r4os_contract2", contract.module("r4os_contract2"));
    const tests = b.addTest(.{ .root_module = root });
    const run = b.addRunArtifact(tests);
    test_step.dependOn(&run.step);
}

fn addLoaderTests(
    b: *std.Build,
    test_step: *std.Build.Step,
    contract: *std.Build.Dependency,
    config: *std.Build.Step.Options,
    optimize: std.builtin.OptimizeMode,
) void {
    const target = b.graph.host;
    const root = b.createModule(.{
        .root_source_file = b.path("loader_tests.zig"),
        .target = target,
        .optimize = optimize,
    });
    root.addOptions("config", config);
    root.addImport("r4os_contract2", contract.module("r4os_contract2"));
    root.addImport("r4os_kernel_contract", b.createModule(.{
        .root_source_file = contract.path("Generated/Kernel/Zig/r4x_api_generated.zig"),
        .target = target,
        .optimize = optimize,
    }));
    root.addImport("r4f_format", b.createModule(.{
        .root_source_file = b.path("kernel/font_format.zig"),
        .target = target,
        .optimize = optimize,
    }));
    const ntfs_format = b.createModule(.{
        .root_source_file = b.path("Support/ntfs_format.zig"),
        .target = target,
        .optimize = optimize,
    });
    root.addImport("ntfs_format", ntfs_format);
    const ntfs_volume = b.createModule(.{
        .root_source_file = b.path("Support/ntfs_volume.zig"),
        .target = target,
        .optimize = optimize,
    });
    ntfs_volume.addImport("ntfs_format", ntfs_format);
    root.addImport("ntfs_volume", ntfs_volume);
    root.addImport("system_update_recovery", b.createModule(.{
        .root_source_file = b.path("Support/system_update_recovery.zig"),
        .target = target,
        .optimize = optimize,
    }));
    root.addImport("upload_publish_claim", b.createModule(.{
        .root_source_file = b.path("Support/upload_publish_claim.zig"),
        .target = target,
        .optimize = optimize,
    }));
    root.addImport("r4_registry_core", b.createModule(.{
        .root_source_file = b.path("Support/registry_core.zig"),
        .target = target,
        .optimize = optimize,
    }));

    const tests = b.addTest(.{ .root_module = root });
    const run = b.addRunArtifact(tests);
    test_step.dependOn(&run.step);
}

fn addProviderNegative(
    b: *std.Build,
    test_step: *std.Build.Step,
    contract: *std.Build.Dependency,
    fixture: []const u8,
    expected_diagnostic: []const u8,
) void {
    const compile = b.addSystemCommand(&.{
        b.graph.zig_exe,
        "build-obj",
        "--dep",
        "kernel_api",
        "--dep",
        "contract2",
    });
    compile.addPrefixedFileArg("-Mroot=", b.path(fixture));
    compile.addArgs(&.{ "--dep", "r4os_kernel_contract" });
    compile.addPrefixedFileArg("-Mkernel_api=", b.path("program/r4x_api.zig"));
    compile.addPrefixedFileArg(
        "-Mr4os_kernel_contract=",
        contract.path("Generated/Kernel/Zig/r4x_api_generated.zig"),
    );
    compile.addArgs(&.{ "--dep", "r4os_base_abi" });
    compile.addPrefixedFileArg("-Mcontract2=", contract.path("Generated/Generation2/Zig/abi.zig"));
    compile.addPrefixedFileArg("-Mr4os_base_abi=", contract.path("Generated/SDK/Zig/package.zig"));
    compile.addArg("-fno-emit-bin");
    compile.expectExitCode(1);
    compile.expectStdErrMatch(expected_diagnostic);
    test_step.dependOn(&compile.step);
}
