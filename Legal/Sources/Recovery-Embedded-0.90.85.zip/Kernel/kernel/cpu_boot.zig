// Early CPU and interrupt foundation for kernel startup.
//
// This layer initializes the x86_64 foundation that must be ready before most
// later kernel subsystems: GDT, IDT, and the initial PIC state.

const gdt = @import("../arch/x86_64/gdt.zig");
const idt = @import("../arch/x86_64/idt.zig");
const fpu = @import("../arch/x86_64/fpu.zig");
const cpu = @import("../platform/cpu.zig");
const monotonic = @import("../platform/monotonic.zig");
const fatal = @import("fatal.zig");
const pic = @import("../arch/x86_64/pic.zig");
const smp = @import("smp.zig");

var initialized = false;

pub fn init() void {
    if (initialized) return;

    gdt.init();
    idt.init();
    pic.init();
    _ = cpu.detect();
    smp.initBsp();
    monotonic.configureCpuClock();
    if (!fpu.init()) fatal.kernelFatal(.cpu, "FPU/SSE task-state init failed");
    @import("../platform/cpu_acceleration.zig").captureCurrentCpu();

    initialized = true;
}

pub fn isInitialized() bool {
    return initialized;
}
