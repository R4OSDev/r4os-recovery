const std = @import("std");
const boot_info = @import("../bootloader/boot_info.zig");
const blocks = @import("blocks.zig");
const owner_locks = @import("owner_locks.zig");
const k = @import("../kernel/log.zig");

pub const FRAME_SIZE: u64 = 4096;
// The legacy Limine handoff maps the low4GiB. Observed UEFI page tables
// can omit higher usable RAM until our own complete direct map is active.
const BOOTSTRAP_PHYS_LIMIT: u64 = 4 * 1024 * 1024 * 1024;

pub const Stats = struct {
    total_frames: u64 = 0,
    free_frames: u64 = 0,
    used_frames: u64 = 0,
    bitmap_bytes: u64 = 0,
    bitmap_base: u64 = 0,
    double_free_errors: u64 = 0,
    bad_free_errors: u64 = 0,
    extent_allocations: u64 = 0,
    extent_allocated_frames: u64 = 0,
    extent_max_frames: u64 = 0,
    extent_frees: u64 = 0,
    extent_freed_frames: u64 = 0,
};

pub const FrameExtent = struct {
    base: u64,
    count: u64,
};

// 0.56.9: PMM-Wachhunde. Ein Double-Free markiert einen IN BENUTZUNG
// befindlichen Frame als frei -> die naechste Vergabe teilt ihn doppelt
// aus und der zweite Besitzer zerschreibt via HHDM fremden RAM (Top-
// Kandidat fuer die rip=0-Crashklasse). Vorher wurden Double-Frees hier
// STUMM geschluckt; jetzt zaehlen sie und melden sich einmalig auf COM1
// (der Gate-serial-markers-Subtest greift die Marker auf).
var double_free_errors: u64 = 0;
var bad_free_errors: u64 = 0;
var pmm_fault_reported: bool = false;
var extent_allocations: u64 = 0;
var extent_allocated_frames: u64 = 0;
var extent_max_frames: u64 = 0;
var extent_frees: u64 = 0;
var extent_freed_frames: u64 = 0;

fn reportPmmFault(kind: []const u8, addr: u64) void {
    if (pmm_fault_reported) return;
    pmm_fault_reported = true;
    k.puts("PMM FAULT ");
    k.puts(kind);
    k.puts(" frame=0x");
    k.putHex(addr, 16);
    k.puts("\r\n");
}

var bitmap: [*]u8 = undefined;
var bitmap_bytes: u64 = 0;
var total_frames: u64 = 0;
var free_frames: u64 = 0;
var next_hint: u64 = 0;
var hhdm_offset: u64 = 0;
var initialized = false;
var allocation_frame_limit: u64 = 0;

pub fn init() bool {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    const entries = boot_info.memoryMap();
    if (entries.len == 0) return false;
    hhdm_offset = boot_info.hhdmOffset() orelse return false;

    const max_addr = highestUsableAddress(entries);
    total_frames = (alignUpChecked(max_addr, FRAME_SIZE) orelse return false) / FRAME_SIZE;
    bitmap_bytes = (alignUpChecked(total_frames, 8) orelse return false) / 8;

    allocation_frame_limit = @min(total_frames, BOOTSTRAP_PHYS_LIMIT / FRAME_SIZE);
    var bitmap_base: ?u64 = null;
    var largest_mapped_len: u64 = 0;
    const needed = alignUpChecked(bitmap_bytes, FRAME_SIZE) orelse return false;
    for (entries) |entry| {
        if (entry.kind != .usable or entry.usable_base >= BOOTSTRAP_PHYS_LIMIT) continue;
        const base = @max(entry.usable_base, FRAME_SIZE);
        const end = @min(checkedAdd(entry.usable_base, entry.usable_len) orelse return false, BOOTSTRAP_PHYS_LIMIT);
        if (end <= base or end - base < needed or end - base <= largest_mapped_len) continue;
        bitmap_base = base;
        largest_mapped_len = end - base;
    }
    const bitmap_phys = bitmap_base orelse return false;
    const bitmap_end = checkedAdd(bitmap_phys, bitmap_bytes) orelse return false;

    bitmap = @ptrFromInt(physToVirt(bitmap_phys));
    @memset(bitmap[0..@intCast(bitmap_bytes)], 0xFF);
    free_frames = 0;
    next_hint = 0;
    double_free_errors = 0;
    bad_free_errors = 0;
    pmm_fault_reported = false;
    extent_allocations = 0;
    extent_allocated_frames = 0;
    extent_max_frames = 0;
    extent_frees = 0;
    extent_freed_frames = 0;

    var i: usize = 0;
    while (i < entries.len) : (i += 1) {
        const entry = entries[i];
        if (entry.kind == .usable) {
            markRange(entry.usable_base, entry.usable_len, false);
        }
    }

    markRange(0, FRAME_SIZE, true);
    markRange(bitmap_phys, bitmap_bytes, true);
    const bitmap_claim_base = alignDown(bitmap_phys, FRAME_SIZE);
    const bitmap_claim_end = alignUpChecked(bitmap_end, FRAME_SIZE) orelse return false;
    _ = blocks.claimPhysicalRange(bitmap_claim_base, bitmap_claim_end - bitmap_claim_base, .kernel, .kernel, 0, "pmm-bitmap") catch return false;
    initialized = true;
    return true;
}

// Called only after the owned CR3 and its complete direct map passed the
// existing switch/readback checks. All allocation paths share this bound.
pub fn completeBootstrapMapping() bool {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (!initialized) return false;
    allocation_frame_limit = total_frames;
    return true;
}

// Existing UI diagnostic: reserve a real high frame through the physical
// owner, verify both ends through the active direct map, zero and return it.
// Production does not call this diagnostic and exposes no new module API.
pub fn verifyHighFrameAccess() bool {
    var frame: ?u64 = null;
    {
        const lock_token = owner_locks.physical_memory.acquire();
        defer owner_locks.physical_memory.release(lock_token);
        if (!initialized or allocation_frame_limit != total_frames) return false;
        // The same UI diagnostic kernel runs the original low-RAM install
        // refusals. Such a machine has no high frame to test; it must still
        // reach the package owner's memory checks.8GB UI cases require OK.
        if (total_frames <= BOOTSTRAP_PHYS_LIMIT / FRAME_SIZE) {
            k.puts("[RECOVERYMEMORY] high_frame_readback=NOT_APPLICABLE reason=no-high-usable-frame\r\n");
            return true;
        }
        var index = BOOTSTRAP_PHYS_LIMIT / FRAME_SIZE;
        while (index < total_frames) : (index += 1) {
            if (isUsed(index)) continue;
            setUsed(index, true);
            free_frames -= 1;
            frame = index * FRAME_SIZE;
            break;
        }
    }
    const physical = frame orelse return false;
    defer freeFrame(physical);
    const first: *volatile u64 = @ptrFromInt(physToVirt(physical));
    const last: *volatile u64 = @ptrFromInt(physToVirt(physical + FRAME_SIZE - @sizeOf(u64)));
    first.* = 0x1690_85ad_4a6b_c123;
    last.* = 0xcafe_0123_890a_bcd4;
    const ok = first.* == 0x1690_85ad_4a6b_c123 and last.* == 0xcafe_0123_890a_bcd4;
    const bytes: [*]u8 = @ptrFromInt(physToVirt(physical));
    @memset(bytes[0..FRAME_SIZE], 0);
    if (!ok) return false;
    k.puts("[RECOVERYMEMORY] high_frame_readback=OK physical=0x");
    k.putHex(physical, 16);
    k.puts("\r\n");
    return true;
}

// 0.56.12: Bitmap wortweise als u64 lesen, wenn die Basis 8-Byte-
// ausgerichtet ist (HHDM ist seitenausgerichtet, in der Praxis immer der
// Fall). Volle Woerter (0xFF..) werden mit EINEM Vergleich uebersprungen
// statt 64 Einzelbit-Tests - der Hotpath allocFrame skaliert dann mit der
// Zahl der belegten WOERTER, nicht der Bits.
fn bitmapWords() ?[*]u64 {
    if ((@intFromPtr(bitmap) & 7) != 0) return null;
    return @ptrCast(@alignCast(bitmap));
}

fn wordCount() u64 {
    return (bitmap_bytes + 7) / 8;
}

pub fn allocFrame() ?u64 {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (!initialized) return null;
    const words = bitmapWords() orelse return allocFrameLinear();

    const wc = (allocation_frame_limit + 63) / 64;
    if (wc == 0) return null;
    var scanned: u64 = 0;
    var wi = next_hint / 64;
    var start_bit: u6 = @intCast(next_hint % 64);
    while (scanned <= wc) : (scanned += 1) {
        if (wi >= wc) {
            wi = 0;
            start_bit = 0;
        }
        var word = words[wi];
        // Bits unterhalb des Starthinweises als belegt maskieren.
        if (start_bit != 0) word |= (@as(u64, 1) << start_bit) - 1;
        if (word != ~@as(u64, 0)) {
            const bit: u6 = @intCast(@ctz(~word));
            const frame = wi * 64 + bit;
            if (frame == 0) {
                // Frame 0 ist reserviert: maskieren, dasselbe Wort erneut.
                start_bit = 1;
                continue;
            }
            if (frame < allocation_frame_limit) {
                words[wi] |= @as(u64, 1) << bit;
                free_frames -= 1;
                next_hint = frame + 1;
                return frame * FRAME_SIZE;
            }
            // frame >= total_frames: Tail-Padding-Bits, naechstes Wort.
        }
        wi += 1;
        start_bit = 0;
    }
    return null;
}

/// Acquires one normal frame and then extends only across immediately
/// following free bitmap bits. This captures natural locality without the
/// unbounded search performed by allocContiguousFrames().
pub fn allocFrameExtent(max_count: u64) ?FrameExtent {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (max_count == 0) return null;
    const base = allocFrame() orelse return null;
    const start = base / FRAME_SIZE;
    var count: u64 = 1;
    while (count < max_count and start + count < allocation_frame_limit and !isUsed(start + count)) : (count += 1) {
        setUsed(start + count, true);
        free_frames -= 1;
    }
    next_hint = start + count;
    extent_allocations +%= 1;
    extent_allocated_frames +%= count;
    if (count > extent_max_frames) extent_max_frames = count;
    return .{ .base = base, .count = count };
}

fn allocFrameLinear() ?u64 {
    var scanned: u64 = 0;
    var frame = next_hint;
    while (scanned < allocation_frame_limit) : (scanned += 1) {
        if (frame >= allocation_frame_limit) frame = 0;
        if (frame == 0) {
            frame = 1;
            continue;
        }
        if (!isUsed(frame)) {
            setUsed(frame, true);
            free_frames -= 1;
            next_hint = frame + 1;
            return frame * FRAME_SIZE;
        }
        frame += 1;
    }
    return null;
}

pub fn allocContiguousFrames(count: u64) ?u64 {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    return allocContiguousFramesBelow(count, std.math.maxInt(u64));
}

pub fn allocContiguousFramesBelow(count: u64, max_phys_addr: u64) ?u64 {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (!initialized or count == 0) return null;
    const addressable_frames = if (max_phys_addr == std.math.maxInt(u64))
        allocation_frame_limit
    else
        @min(allocation_frame_limit, (max_phys_addr + 1) / FRAME_SIZE);
    if (count > addressable_frames) return null;
    const words = bitmapWords();
    var start: u64 = 1;
    while (start <= addressable_frames - count) : (start += 1) {
        // 0.56.12: volle Woerter beim Fehlschlag ueberspringen.
        if (words) |w| {
            if (isUsed(start) and (start & 63) == 0 and w[start / 64] == ~@as(u64, 0)) {
                start += 63;
                continue;
            }
        }
        var offset: u64 = 0;
        while (offset < count and !isUsed(start + offset)) : (offset += 1) {}
        if (offset == count) {
            var mark: u64 = 0;
            while (mark < count) : (mark += 1) setUsed(start + mark, true);
            free_frames -= count;
            next_hint = start + count;
            return start * FRAME_SIZE;
        }
        start += offset;
    }
    return null;
}

pub fn freeContiguousFrames(addr: u64, count: u64) void {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (!initialized or addr % FRAME_SIZE != 0 or count == 0) return;
    const start = addr / FRAME_SIZE;
    if (start + count > total_frames) return;
    var offset: u64 = 0;
    while (offset < count) : (offset += 1) {
        const frame = start + offset;
        if (!isUsed(frame)) continue;
        setUsed(frame, false);
        free_frames += 1;
    }
    if (start < next_hint) next_hint = start;
}

pub fn freeFrameExtent(extent: FrameExtent) void {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (extent.count == 0) return;
    freeContiguousFrames(extent.base, extent.count);
    extent_frees +%= 1;
    extent_freed_frames +%= extent.count;
}

pub fn freeFrame(addr: u64) void {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    if (!initialized) return;
    if (addr % FRAME_SIZE != 0) {
        bad_free_errors +%= 1;
        reportPmmFault("BAD-FREE-ALIGN", addr);
        return;
    }
    const frame = addr / FRAME_SIZE;
    if (frame >= total_frames) {
        bad_free_errors +%= 1;
        reportPmmFault("BAD-FREE-RANGE", addr);
        return;
    }
    if (!isUsed(frame)) {
        double_free_errors +%= 1;
        reportPmmFault("DOUBLE-FREE", addr);
        return;
    }
    setUsed(frame, false);
    free_frames += 1;
    if (frame < next_hint) next_hint = frame;
}

pub fn stats() Stats {
    const lock_token = owner_locks.physical_memory.acquire();
    defer owner_locks.physical_memory.release(lock_token);
    return .{
        .total_frames = total_frames,
        .free_frames = free_frames,
        .used_frames = total_frames - free_frames,
        .bitmap_bytes = bitmap_bytes,
        .bitmap_base = if (initialized) virtToPhys(@intFromPtr(bitmap)) else 0,
        .double_free_errors = double_free_errors,
        .bad_free_errors = bad_free_errors,
        .extent_allocations = extent_allocations,
        .extent_allocated_frames = extent_allocated_frames,
        .extent_max_frames = extent_max_frames,
        .extent_frees = extent_frees,
        .extent_freed_frames = extent_freed_frames,
    };
}

pub fn dumpStats() void {
    const s = stats();
    k.puts("  Physical frames: total=");
    k.putDec(s.total_frames);
    k.puts(" free=");
    k.putDec(s.free_frames);
    k.puts(" used=");
    k.putDec(s.used_frames);
    k.puts("\r\n");
    k.puts("  Physical extents: alloc=");
    k.putDec(s.extent_allocations);
    k.puts(" frames=");
    k.putDec(s.extent_allocated_frames);
    k.puts(" max=");
    k.putDec(s.extent_max_frames);
    k.puts(" free=");
    k.putDec(s.extent_frees);
    k.puts(" returned=");
    k.putDec(s.extent_freed_frames);
    k.puts("\r\n");
    k.puts("  PMM bitmap: base=0x");
    k.putHex(s.bitmap_base, 16);
    k.puts(" bytes=");
    k.putDec(s.bitmap_bytes);
    k.puts("\r\n");
}

fn highestUsableAddress(entries: []const boot_info.MemoryMapEntry) u64 {
    var high: u64 = 0;
    var i: usize = 0;
    while (i < entries.len) : (i += 1) {
        const entry = entries[i];
        if (entry.kind != .usable or entry.usable_len == 0) continue;
        const end = entry.usable_base + entry.usable_len;
        if (end > high) high = end;
    }
    return high;
}

pub fn physToVirt(addr: u64) u64 {
    return checkedAdd(addr, hhdm_offset) orelse 0;
}

pub fn virtToPhys(addr: u64) u64 {
    if (addr < hhdm_offset) return 0;
    return addr - hhdm_offset;
}

fn markRange(base: u64, len: u64, used: bool) void {
    if (len == 0) return;
    const range_end = checkedAdd(base, len) orelse return;
    const start_addr = if (used) alignDown(base, FRAME_SIZE) else (alignUpChecked(base, FRAME_SIZE) orelse return);
    const end_addr = if (used) (alignUpChecked(range_end, FRAME_SIZE) orelse return) else alignDown(range_end, FRAME_SIZE);
    const start = start_addr / FRAME_SIZE;
    const end = end_addr / FRAME_SIZE;
    var frame = start;
    while (frame < end) : (frame += 1) {
        if (frame >= total_frames) break;
        const was_used = isUsed(frame);
        if (was_used != used) {
            setUsed(frame, used);
            if (used) {
                free_frames -= 1;
            } else {
                free_frames += 1;
            }
        }
    }
}

fn isUsed(frame: u64) bool {
    const byte_index: usize = @intCast(frame / 8);
    const bit: u3 = @intCast(frame % 8);
    return (bitmap[byte_index] & (@as(u8, 1) << bit)) != 0;
}

fn setUsed(frame: u64, used: bool) void {
    const byte_index: usize = @intCast(frame / 8);
    const bit: u3 = @intCast(frame % 8);
    if (used) {
        bitmap[byte_index] |= @as(u8, 1) << bit;
    } else {
        bitmap[byte_index] &= ~(@as(u8, 1) << bit);
    }
}

fn alignDown(value: u64, alignment: u64) u64 {
    return value & ~(alignment - 1);
}

fn alignUpChecked(value: u64, alignment: u64) ?u64 {
    const adjusted = checkedAdd(value, alignment - 1) orelse return null;
    return alignDown(adjusted, alignment);
}

fn checkedAdd(a: u64, b: u64) ?u64 {
    const result = a +% b;
    if (result < a) return null;
    return result;
}
