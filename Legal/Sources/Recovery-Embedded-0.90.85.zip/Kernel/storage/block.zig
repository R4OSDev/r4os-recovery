const diag_screen = @import("../kernel/diag_screen.zig");
const block_dispatch = @import("block_dispatch.zig");
const block_split = @import("block_split.zig");
const access = @import("access_runtime.zig");
const drive = @import("../fs/drive.zig");
const heap = @import("../memory/heap.zig");
const owner_locks = @import("../memory/owner_locks.zig");
const k = @import("../kernel/log.zig");
const std = @import("std");
const scheduler = @import("../sched/scheduler.zig");
const sync = @import("../sched/sync.zig");
const sched_task = @import("../sched/task.zig");
const task_context = @import("../sched/task_context.zig");
const timer = @import("../kernel/timer.zig");

const MAX_DEVICES: usize = 16;
pub const MAX_REQUEST_QUEUE_DEPTH: usize = 16;

pub const ReadFn = *const fn (ctx: ?*anyopaque, lba: u64, sectors: u16, out: []u8) bool;
pub const WriteFn = *const fn (ctx: ?*anyopaque, lba: u64, sectors: u16, data: []const u8) bool;
pub const FlushFn = *const fn (ctx: ?*anyopaque) bool;
pub const AsyncCompleteFn = *const fn (handle: u64, result: i32, bytes: u32) callconv(.c) void;

pub const ASYNC_RESULT_OK: i32 = 0;
pub const ASYNC_RESULT_ERROR: i32 = -1;
pub const ASYNC_RESULT_CANCELLED: i32 = -2;
pub const ASYNC_RESULT_TIMEOUT: i32 = -3;
pub const ASYNC_RESULT_RESET: i32 = -4;
pub const ASYNC_RESULT_SHUTDOWN: i32 = -5;

pub const CANCEL_REASON_TIMEOUT: u32 = 1;
pub const CANCEL_REASON_CALLER: u32 = 2;
pub const CANCEL_REASON_RESET: u32 = 3;
pub const CANCEL_REASON_SHUTDOWN: u32 = 4;

pub const AsyncRequest = struct {
    handle: u64,
    kind: RequestKind,
    lba: u64,
    sectors: u16,
    buffer: ?[*]u8,
    const_buffer: ?[*]const u8,
    buffer_len: usize,
    complete: AsyncCompleteFn,
};

// `submit` is nonblocking. Zero transfers request ownership to the backend;
// every accepted request must publish exactly one completion. A nonzero
// result rejects ownership unless the backend already completed inline.
pub const AsyncSubmitFn = *const fn (ctx: ?*anyopaque, request: *const AsyncRequest) i32;
pub const AsyncCancelFn = *const fn (ctx: ?*anyopaque, handle: u64, reason: u32) i32;
// A successful reset proves that no old command can access its buffer again.
pub const AsyncResetFn = *const fn (ctx: ?*anyopaque, reason: u32) i32;

pub const Bus = enum {
    unknown,
    ata,
    ahci,
    nvme,
    usb,
    ram,
    virtio,
};

pub const State = enum {
    registered,
    active,
    busy,
    recovering,
    failed,
};

pub const Source = enum {
    builtin,
    preload,
    disk,
};

pub const RequestKind = enum {
    none,
    read,
    write,
    flush,
};

pub const RequestSnapshot = struct {
    id: u64 = 0,
    kind: RequestKind = .none,
    lba: u64 = 0,
    sectors: u16 = 0,
};

pub const SenseSnapshot = struct {
    valid: bool = false,
    opcode: u8 = 0,
    key: u8 = 0,
    asc: u8 = 0,
    ascq: u8 = 0,
};

const RequestState = enum(u8) {
    free,
    queued,
    active,
    completed,
};

const RequestSlot = struct {
    state: RequestState = .free,
    id: u64 = 0,
    kind: RequestKind = .none,
    lba: u64 = 0,
    sectors: u16 = 0,
    buffer: ?[*]u8 = null,
    const_buffer: ?[*]const u8 = null,
    buffer_len: usize = 0,
    ok: bool = false,
    err: Error = .none,
    submit_tick: u64 = 0,
    start_tick: u64 = 0,
    complete_tick: u64 = 0,
    // Once a runtime request has entered the backend, its buffer must remain
    // alive until finishRequest observes that the synchronous callback has
    // returned. Bounce ownership may transfer to a late completion. A direct
    // resident borrower instead remains blocked until that callback returns.
    buffer_ownership: block_dispatch.BufferOwnership = .none,
    timeout_requested: bool = false,
    caller_detached: bool = false,
    cancel_requested: bool = false,
    completion_override: Error = .none,
    backend_handle: u64 = 0,
    completion_latch: block_dispatch.CompletionLatch = .{},
    execution_mode: ExecutionMode = .boot_inline,
};

const RequestExecution = struct {
    slot_index: usize,
    id: u64,
    kind: RequestKind,
    lba: u64,
    sectors: u16,
    buffer: ?[*]u8,
    const_buffer: ?[*]const u8,
    buffer_len: usize,
    buffer_ownership: block_dispatch.BufferOwnership,
    start_tick: u64,
    mode: ExecutionMode,
    backend_handle: u64,
};

const RequestResult = struct {
    ok: bool = false,
    err: Error = .none,
    buffer_detached: bool = false,
};

const ExecutionMode = enum(u8) {
    boot_inline,
    runtime_worker,
};

pub const Error = enum {
    none,
    busy,
    invalid_request,
    request_too_large,
    out_of_range,
    buffer_too_small,
    no_writer,
    timeout,
    backend_read,
    backend_write,
    backend_flush,
    cancelled,
    reset,
    shutdown,
};

/// Exact committed prefix of a logical write.  Filesystem/cache callers use
/// this to invalidate only sectors that definitely reached the backend when
/// a later backend-sized chunk fails.
pub const TransferResult = struct {
    sectors_completed: u16 = 0,
    err: Error = .none,
};

pub const Stats = struct {
    next_request_id: u64 = 0,
    completions: u64 = 0,
    busy_rejections: u64 = 0,
    timeout_failures: u64 = 0,
    active_request: RequestSnapshot = .{},
    last_request: RequestSnapshot = .{},
    queued_requests: u64 = 0,
    dequeued_requests: u64 = 0,
    queue_full_waits: u64 = 0,
    queue_full_rejections: u64 = 0,
    completion_waits: u64 = 0,
    completion_timeouts: u64 = 0,
    completion_total_ticks: u64 = 0,
    completion_max_ticks: u64 = 0,
    completion_last_ticks: u64 = 0,
    completion_signals: u64 = 0,
    worker_requests: u64 = 0,
    worker_completions: u64 = 0,
    boot_inline_requests: u64 = 0,
    boot_inline_completions: u64 = 0,
    queue_high_water: u32 = 0,
    read_ops: u64 = 0,
    read_sectors: u64 = 0,
    read_failures: u64 = 0,
    write_ops: u64 = 0,
    write_sectors: u64 = 0,
    write_failures: u64 = 0,
    flush_ops: u64 = 0,
    flush_failures: u64 = 0,
    backend_recoveries: u64 = 0,
    backend_recovery_failures: u64 = 0,
    direct_requests: u64 = 0,
    direct_bytes: u64 = 0,
    bounce_allocations: u64 = 0,
    bounce_bytes: u64 = 0,
    bounce_copy_bytes: u64 = 0,
    direct_timeout_waits: u64 = 0,
    async_submissions: u64 = 0,
    async_completions: u64 = 0,
    async_cancel_requests: u64 = 0,
    async_resets: u64 = 0,
    duplicate_completions: u64 = 0,
    late_completions: u64 = 0,
    in_flight_high_water: u32 = 0,
    last_sense: SenseSnapshot = .{},
    last_error: Error = .none,
};

pub const RuntimeSummary = struct {
    worker_started: u32 = 0,
    worker_task_id: u32 = 0,
    worker_wakeups: u64 = 0,
    worker_runs: u64 = 0,
    worker_idle_waits: u64 = 0,
    worker_queue_scans: u64 = 0,
    worker_runtime_requests: u64 = 0,
    worker_runtime_completions: u64 = 0,
    boot_inline_requests: u64 = 0,
    boot_inline_completions: u64 = 0,
    completion_signals: u64 = 0,
    controller_count: u32 = 0,
    worker_count: u32 = 0,
    worker_start_failures: u64 = 0,
    worker_parallel_active: u32 = 0,
    worker_parallel_active_max: u32 = 0,
    direct_requests: u64 = 0,
    direct_bytes: u64 = 0,
    bounce_allocations: u64 = 0,
    bounce_bytes: u64 = 0,
    bounce_copy_bytes: u64 = 0,
    direct_timeout_waits: u64 = 0,
    async_submissions: u64 = 0,
    async_completions: u64 = 0,
    async_cancel_requests: u64 = 0,
    async_resets: u64 = 0,
    duplicate_completions: u64 = 0,
    late_completions: u64 = 0,
    in_flight: u32 = 0,
    in_flight_high_water: u32 = 0,
};

pub const Device = struct {
    // Assigned by the registry; never supplied by a driver or reused after retirement.
    access_ref: access.DeviceRef = .{ .slot = 0, .generation = 0 },
    name: []const u8,
    // Hardware-provided text when available; distinct from the registry name.
    model: []const u8 = "",
    driver: []const u8 = "unknown",
    bus: Bus = .unknown,
    controller: []const u8 = "unknown",
    port: u8 = 0,
    sector_size: u32,
    sector_count: u64,
    max_sectors_per_request: u16 = 0,
    queue_depth: u16 = 1,
    timeout_ticks: u64 = 0,
    removable: bool = false,
    writable: bool = false,
    // The backend already classifies transport failures, performs recovery
    // and replays an idempotent command with an exact bounded policy.
    // Higher cache layers must not multiply that retry sequence.
    owns_transport_retry: bool = false,
    source: Source = .builtin,
    owner_id: u32 = 0,
    ctx: ?*anyopaque,
    read_fn: ReadFn,
    write_fn: ?WriteFn = null,
    flush_fn: ?FlushFn = null,
    async_submit_fn: ?AsyncSubmitFn = null,
    async_cancel_fn: ?AsyncCancelFn = null,
    async_reset_fn: ?AsyncResetFn = null,
    state: State = .registered,
    resetting: bool = false,
    slot_index: u8 = 0,
    stats: Stats = .{},
    active_executions: u32 = 0,
    controller_lane: u8 = block_dispatch.no_lane,
    request_slots: [MAX_REQUEST_QUEUE_DEPTH]RequestSlot = .{RequestSlot{}} ** MAX_REQUEST_QUEUE_DEPTH,
    slot_available: sync.WaitQueue = sync.WaitQueue.init(),
    completion_available: sync.WaitQueue = sync.WaitQueue.init(),
    queue_lock: sync.Mutex = sync.Mutex.initClass("block-device", sync.LockRank.block_device, .sleepable),
};

const DeviceSlot = struct {
    used: bool = false,
    retiring: bool = false,
    offline: bool = false,
    pin_count: u32 = 0,
    retire_generation: u64 = 0,
    device: Device = undefined,
};

const DevicePin = struct {
    slot: *DeviceSlot,
    device: *Device,
    unwind: task_context.UnwindToken,
    active: bool = true,
};

// A prepared unregister owns the retiring admission barrier until it is
// either committed or cancelled. Index plus retirement generation avoids
// exposing DeviceSlot and rejects copied stale tokens after cancel/reuse.
pub const UnregisterToken = struct {
    index: usize = 0,
    generation: u64 = 0,
    active: bool = false,
};

// Device addresses are stable for the complete lifetime of one registration.
// Unregister leaves a tombstone instead of shifting later Device values (and
// their embedded WaitQueues/Mutex); register may reuse only a quiescent slot.
var devices: [MAX_DEVICES]DeviceSlot = .{DeviceSlot{}} ** MAX_DEVICES;
var device_count: usize = 0;
var device_slot_count: usize = 0;
// Session-wide media policy, applied before physical volumes are admitted.
// Hardware/USB HID owners are independent of block-device visibility.
var excluded_bus: ?Bus = null;
var runtime_worker_started = false;
var runtime_worker_task_id: u32 = 0;
var runtime_worker_task_generation: u64 = 0;
var primary_controller_lane: u8 = block_dispatch.no_lane;
var controller_map: block_dispatch.ControllerMap = .{};
const ControllerRuntime = struct {
    worker_started: bool = false,
    worker_task_id: u32 = 0,
    worker_task_generation: u64 = 0,
    event: sync.EventV2 = sync.EventV2.initMode(false, .auto_reset),
};
var controller_runtime: [block_dispatch.max_controllers]ControllerRuntime =
    .{ControllerRuntime{}} ** block_dispatch.max_controllers;
const worker_names = [_][]const u8{
    "block-work",  "block-work1", "block-work2", "block-work3",
    "block-work4", "block-work5", "block-work6", "block-work7",
};
var runtime_summary: RuntimeSummary = .{};
var next_backend_handle_sequence: u64 = 0;

pub fn init() void {
    access.initForBoot();
    devices = .{DeviceSlot{}} ** MAX_DEVICES;
    device_count = 0;
    device_slot_count = 0;
    excluded_bus = null;
    runtime_worker_started = false;
    runtime_worker_task_id = 0;
    runtime_worker_task_generation = 0;
    primary_controller_lane = block_dispatch.no_lane;
    controller_map = .{};
    controller_runtime = .{ControllerRuntime{}} ** block_dispatch.max_controllers;
    runtime_summary = .{};
    next_backend_handle_sequence = 0;
}

pub fn initRuntimeWorker() bool {
    if (runtimeWorkerIdentityAlive()) return true;
    runtime_worker_started = false;
    runtime_worker_task_id = 0;
    runtime_worker_task_generation = 0;
    primary_controller_lane = block_dispatch.no_lane;
    var lane: usize = 0;
    while (lane < controller_runtime.len) : (lane += 1) {
        controller_runtime[lane].worker_started = false;
        controller_runtime[lane].worker_task_id = 0;
        controller_runtime[lane].worker_task_generation = 0;
        controller_runtime[lane].event = sync.EventV2.initMode(false, .auto_reset);
    }

    lane = 0;
    while (lane < controller_runtime.len) : (lane += 1) {
        if (!controller_map.used[lane]) continue;
        if (primary_controller_lane == block_dispatch.no_lane) {
            if (!startControllerWorker(@intCast(lane), true)) {
                runtime_summary.worker_started = 0;
                runtime_summary.worker_task_id = 0;
                return false;
            }
            primary_controller_lane = @intCast(lane);
            continue;
        }
        if (!startControllerWorker(@intCast(lane), false)) {
            runtime_summary.worker_start_failures +%= 1;
        }
    }
    if (primary_controller_lane == block_dispatch.no_lane) {
        // The runtime storage contract always has at least one boot device.
        // Fail visibly instead of publishing a worker that can own no queue.
        runtime_summary.worker_started = 0;
        runtime_summary.worker_task_id = 0;
        return false;
    }
    const primary = &controller_runtime[primary_controller_lane];
    runtime_worker_started = true;
    runtime_worker_task_id = primary.worker_task_id;
    runtime_worker_task_generation = primary.worker_task_generation;
    runtime_summary.worker_started = 1;
    runtime_summary.worker_task_id = primary.worker_task_id;
    return true;
}

pub fn runtimeWorkerReady() bool {
    return scheduler.currentId() != null and runtimeWorkerIdentityAlive();
}

pub fn runtimeWorkerSummary() RuntimeSummary {
    var out = runtime_summary;
    const alive = runtimeWorkerIdentityAlive();
    out.worker_started = if (alive) 1 else 0;
    out.worker_task_id = if (alive) runtime_worker_task_id else 0;
    out.controller_count = controller_map.count();
    out.worker_count = 0;
    var lane: usize = 0;
    while (lane < controller_runtime.len) : (lane += 1) {
        if (controller_map.used[lane] and controllerWorkerAlive(@intCast(lane))) {
            out.worker_count += 1;
        }
    }
    return out;
}

fn runtimeWorkerIdentityAlive() bool {
    return runtime_worker_started and
        runtime_worker_task_id != 0 and
        runtime_worker_task_generation != 0 and
        sched_task.isAliveIdentity(runtime_worker_task_id, runtime_worker_task_generation);
}

fn controllerWorkerAlive(lane: u8) bool {
    if (lane >= controller_runtime.len) return false;
    const runtime = &controller_runtime[lane];
    return runtime.worker_started and
        runtime.worker_task_id != 0 and
        runtime.worker_task_generation != 0 and
        sched_task.isAliveIdentity(runtime.worker_task_id, runtime.worker_task_generation);
}

fn startControllerWorker(lane: u8, critical: bool) bool {
    if (lane >= controller_runtime.len) return false;
    if (controllerWorkerAlive(lane)) return true;
    const worker = if (critical)
        sched_task.createKernelThreadCriticalWithRole(worker_names[lane], workerMain, .batch)
    else
        sched_task.createKernelThreadWithRole(worker_names[lane], workerMain, .batch);
    const task = worker orelse return false;
    controller_runtime[lane].worker_started = true;
    controller_runtime[lane].worker_task_id = task.id;
    controller_runtime[lane].worker_task_generation = task.generation;
    return true;
}

pub fn register(device: Device) ?usize {
    const reference = registerReference(device) orelse return null;
    return reference.slot;
}

// Capture the generation at publication, before any callback or wait.
pub fn registerReference(device: Device) ?access.DeviceRef {
    const irq_flags = owner_locks.storage.acquire();
    const result = registerLocked(device);
    const controller_lane = if (result) |index| devices[index].device.controller_lane else block_dispatch.no_lane;
    const reference = if (result) |index| devices[index].device.access_ref else null;
    owner_locks.storage.release(irq_flags);
    if (result != null) {
        if (runtimeWorkerIdentityAlive() and !controllerWorkerAlive(controller_lane)) {
            if (!startControllerWorker(controller_lane, false)) {
                runtime_summary.worker_start_failures +%= 1;
            }
        }
    }
    return reference;
}

fn registerLocked(device: Device) ?usize {
    if (device_count >= MAX_DEVICES) return null;
    if (findByNameLocked(device.name) != null) return null;
    if (device.queue_depth == 0 or @as(usize, device.queue_depth) > MAX_REQUEST_QUEUE_DEPTH) return null;

    var target_index: usize = 0;
    while (target_index < device_slot_count and devices[target_index].used) : (target_index += 1) {}
    if (target_index == device_slot_count and device_slot_count >= devices.len) return null;
    const controller_lane = controller_map.assign(device.controller) orelse return null;
    if (target_index == device_slot_count) device_slot_count += 1;

    var normalized = device;
    // queue_depth is the hardware in-flight limit. Synchronous callbacks are
    // adapted through one execution lane even if an old descriptor advertised
    // a larger software queue.
    if (normalized.async_submit_fn == null) normalized.queue_depth = 1;
    normalized.access_ref = access.registerDeviceLocked(@intCast(target_index), device.sector_count) catch return null;
    normalized.state = .registered;
    normalized.resetting = false;
    normalized.slot_index = @intCast(target_index);
    normalized.stats = .{};
    normalized.active_executions = 0;
    normalized.controller_lane = controller_lane;
    normalized.request_slots = .{RequestSlot{}} ** MAX_REQUEST_QUEUE_DEPTH;
    normalized.slot_available = sync.WaitQueue.init();
    normalized.completion_available = sync.WaitQueue.init();
    normalized.queue_lock = sync.Mutex.initClass("block-device", sync.LockRank.block_device, .sleepable);
    devices[target_index].device = normalized;
    devices[target_index].retiring = false;
    devices[target_index].offline = false;
    devices[target_index].pin_count = 0;
    devices[target_index].used = true;
    device_count += 1;
    return target_index;
}

pub fn unregister(index: usize) bool {
    var token = prepareUnregister(index) orelse return false;
    if (commitUnregister(&token)) return true;
    _ = cancelUnregister(&token);
    return false;
}

// Detach closes new I/O. Existing pinned work can still reach its backend to
// receive a real error; mounted/busy registrations retain their exact identity.
pub fn offlineExact(reference: access.DeviceRef) void {
    const flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(flags);
    if (reference.slot >= device_slot_count) return;
    const slot = &devices[reference.slot];
    if (slot.used and slot.device.access_ref.generation == reference.generation) slot.offline = true;
}

pub fn unregisterExact(reference: access.DeviceRef) bool {
    var token = prepareUnregisterExpected(reference.slot, reference) orelse return false;
    if (commitUnregister(&token)) return true;
    _ = cancelUnregister(&token);
    return false;
}

// Stop new admissions and prove the complete device lifetime is quiescent,
// but leave the registration intact. Callers may prepare several devices and
// cancel all of them without having partially removed an owner.
pub fn prepareUnregister(index: usize) ?UnregisterToken {
    return prepareUnregisterExpected(index, null);
}

fn prepareUnregisterExpected(index: usize, expected: ?access.DeviceRef) ?UnregisterToken {
    const slot = beginRetirement(index, expected) orelse return null;
    if (hasMountedDrive(index)) {
        cancelRetirement(slot);
        return null;
    }

    const device = &slot.device;
    if (!deviceIsQuiescent(device)) {
        cancelRetirement(slot);
        return null;
    }

    // Closing is the final successful-unregister boundary. It prevents the
    // stable embedded synchronization objects from accepting a late waiter
    // while the slot is a tombstone. A surprising raced waiter keeps the
    // registration alive and all queues are reopened after cancellation.
    const slot_waiters = device.slot_available.close(.cancelled);
    const completion_waiters = device.completion_available.close(.cancelled);
    const mutex_waiters = device.queue_lock.queue.close(.cancelled);
    if (slot_waiters != 0 or completion_waiters != 0 or mutex_waiters != 0) {
        _ = device.slot_available.reopen();
        _ = device.completion_available.reopen();
        _ = device.queue_lock.queue.reopen();
        cancelRetirement(slot);
        return null;
    }

    return .{
        .index = index,
        .generation = slot.retire_generation,
        .active = true,
    };
}

pub fn commitUnregister(token: *UnregisterToken) bool {
    if (!token.active) return false;
    const slot = preparedSlot(token.index, token.generation) orelse return false;
    if (!commitRetirement(slot)) return false;
    token.active = false;
    return true;
}

pub fn cancelUnregister(token: *UnregisterToken) bool {
    if (!token.active) return false;
    const slot = preparedSlot(token.index, token.generation) orelse {
        token.active = false;
        return false;
    };
    const device = &slot.device;

    _ = device.slot_available.reopen();
    _ = device.completion_available.reopen();
    _ = device.queue_lock.queue.reopen();
    cancelRetirement(slot);
    token.active = false;
    return true;
}

fn preparedSlot(index: usize, generation: u64) ?*DeviceSlot {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    if (index >= device_slot_count) return null;
    const slot = &devices[index];
    if (!slot.used or !slot.retiring or slot.retire_generation != generation) return null;
    return slot;
}

fn beginRetirement(index: usize, expected: ?access.DeviceRef) ?*DeviceSlot {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    if (index >= device_slot_count) return null;
    const slot = &devices[index];
    if (!slot.used or slot.retiring) return null;
    if (expected) |ref| if (slot.device.access_ref.slot != ref.slot or slot.device.access_ref.generation != ref.generation) return null;
    if (slot.retire_generation == 0xFFFF_FFFF_FFFF_FFFF) return null;
    access.beginRetirementLocked(slot.device.access_ref) catch return null;

    // Admission is stopped before the pin snapshot. A live operation makes
    // unregister a non-destructive retryable failure; it can then unwind its
    // task-owned pin without ever observing reused Device storage.
    slot.retiring = true;
    slot.retire_generation += 1;
    if (slot.pin_count != 0) {
        slot.retiring = false;
        access.cancelRetirementLocked(slot.device.access_ref);
        return null;
    }
    return slot;
}

fn cancelRetirement(slot: *DeviceSlot) void {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    if (slot.used) {
        slot.retiring = false;
        access.cancelRetirementLocked(slot.device.access_ref);
    }
}

fn commitRetirement(slot: *DeviceSlot) bool {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    if (!slot.used or !slot.retiring or slot.pin_count != 0) return false;
    access.retireDeviceLocked(slot.device.access_ref) catch return false;
    const retired_lane = slot.device.controller_lane;
    slot.used = false;
    slot.retiring = false;
    if (device_count != 0) device_count -= 1;
    if (!controllerLaneInUseLocked(retired_lane)) controller_map.clear(retired_lane);
    return true;
}

fn controllerLaneInUseLocked(lane: u8) bool {
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        if (devices[index].used and devices[index].device.controller_lane == lane) return true;
    }
    return false;
}

fn deviceIsQuiescent(device: *Device) bool {
    if (device.resetting or device.active_executions != 0 or countUsedSlots(device) != 0) return false;
    if (device.queue_lock.owner != 0 or device.queue_lock.depth != 0) return false;
    if (device.slot_available.hasWaiters()) return false;
    if (device.completion_available.hasWaiters()) return false;
    if (device.queue_lock.queue.hasWaiters()) return false;
    return true;
}

fn hasMountedDrive(block_index: usize) bool {
    var letter: u8 = 'A';
    while (letter <= 'Z') : (letter += 1) {
        const d = drive.get(letter) orelse continue;
        if (d.block_device_index != null and d.block_device_index.? == block_index) return true;
    }
    return false;
}

pub fn findByName(name: []const u8) ?usize {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    return findByNameLocked(name);
}

fn findByNameLocked(name: []const u8) ?usize {
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        if (!devices[index].used or devices[index].retiring or devices[index].offline or busExcluded(devices[index].device.bus)) continue;
        if (strEqIgnoreCase(devices[index].device.name, name)) return index;
    }
    return null;
}

pub fn count() usize {
    const flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(flags);
    var visible: usize = 0;
    for (devices[0..device_slot_count]) |*slot| {
        if (slot.used and !slot.retiring and !slot.offline and !busExcluded(slot.device.bus)) visible += 1;
    }
    return visible;
}

pub fn excludeBusBeforeMount(bus: Bus) bool {
    if (bus == .ram) return false;
    // This is a boot policy, never an unmount/revocation substitute.
    for (0..drive.DRIVE_COUNT) |i| if (drive.atIndex(i)) |mounted| {
        if (mounted.block_device_index) |index| {
            const device = get(index) orelse continue;
            if (device.bus == bus) return false;
        }
    };
    const flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(flags);
    if (excluded_bus != null) return excluded_bus.? == bus;
    for (devices[0..device_slot_count]) |*slot| {
        if (slot.used and slot.device.bus == bus and (slot.pin_count != 0 or slot.device.active_executions != 0)) return false;
    }
    excluded_bus = bus;
    return true;
}

fn busExcluded(bus: Bus) bool {
    return excluded_bus != null and excluded_bus.? == bus;
}

pub fn isBusVisible(bus: Bus) bool {
    const flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(flags);
    return !busExcluded(bus);
}

pub fn slotCount() usize {
    return device_slot_count;
}

pub fn maxDevices() usize {
    return MAX_DEVICES;
}

pub const Identity = struct {
    reference: access.DeviceRef,
    sectors: u64,
    sector_bytes: u32,
    writable: bool,
    bus: Bus,
    name: [32]u8 = .{0} ** 32,
    model: [64]u8 = .{0} ** 64,
    driver: [32]u8 = .{0} ** 32,
};

// Copy under the registry owner; no pointer into a driver-owned string or a
// reusable DeviceSlot crosses the public inventory boundary.
pub fn identity(index: usize) ?Identity {
    const guard = owner_locks.storage.acquire();
    defer owner_locks.storage.release(guard);
    if (index >= device_slot_count) return null;
    const slot = &devices[index];
    if (!slot.used or slot.retiring or slot.offline or busExcluded(slot.device.bus)) return null;
    const d = &slot.device;
    var result: Identity = .{ .reference = d.access_ref, .sectors = d.sector_count, .sector_bytes = d.sector_size, .writable = d.writable, .bus = d.bus };
    copyIdentityText(&result.name, d.name);
    copyIdentityText(&result.model, d.model);
    copyIdentityText(&result.driver, d.driver);
    return result;
}

fn copyIdentityText(out: []u8, value: []const u8) void {
    const len = @min(out.len - 1, value.len);
    @memcpy(out[0..len], value[0..len]);
}

pub fn get(index: usize) ?*const Device {
    const irq_flags = owner_locks.storage.acquire();
    defer owner_locks.storage.release(irq_flags);
    if (index >= device_slot_count or !devices[index].used or devices[index].retiring or devices[index].offline or busExcluded(devices[index].device.bus)) return null;
    return &devices[index].device;
}

fn pinDevice(index: usize) ?DevicePin {
    return pinDeviceExpected(index, null, false);
}

fn pinDeviceExpected(index: usize, expected: ?access.DeviceRef, drain: bool) ?DevicePin {
    const unwind = task_context.enterUnwind();
    if (!unwind.admitted()) return null;

    const irq_flags = owner_locks.storage.acquire();
    if (index >= device_slot_count or
        !devices[index].used or
        devices[index].retiring or
        (devices[index].offline and !(drain and devices[index].pin_count != 0)) or
        (if (expected) |ref| devices[index].device.access_ref.generation != ref.generation else false) or
        busExcluded(devices[index].device.bus) or
        devices[index].pin_count == 0xFFFF_FFFF)
    {
        owner_locks.storage.release(irq_flags);
        _ = task_context.leaveUnwind(unwind);
        return null;
    }
    const slot = &devices[index];
    slot.pin_count += 1;
    const device = &slot.device;
    owner_locks.storage.release(irq_flags);
    return .{ .slot = slot, .device = device, .unwind = unwind };
}

fn unpinDevice(pin: *DevicePin) void {
    if (!pin.active) return;
    const irq_flags = owner_locks.storage.acquire();
    if (pin.slot.pin_count != 0) pin.slot.pin_count -= 1;
    pin.active = false;
    owner_locks.storage.release(irq_flags);
    _ = task_context.leaveUnwind(pin.unwind);
}

pub fn queueUsed(index: usize) u32 {
    var pin = pinDevice(index) orelse return 0;
    defer unpinDevice(&pin);
    return countUsedSlots(pin.device);
}

pub fn beginBackendRecovery(index: usize) void {
    var pin = pinDevice(index) orelse return;
    defer unpinDevice(&pin);
    // Recovery runs inside the active backend callback, hence the normal
    // state is necessarily .busy here.  Preserve that distinction for the
    // watchdog instead of suppressing the only useful recovery telemetry.
    pin.device.state = .recovering;
}

pub fn finishBackendRecovery(index: usize, ok: bool) void {
    var pin = pinDevice(index) orelse return;
    defer unpinDevice(&pin);
    const device = pin.device;
    device.stats.backend_recoveries += 1;
    if (ok) {
        device.state = if (device.active_executions != 0) .busy else .active;
    } else {
        device.stats.backend_recovery_failures += 1;
        device.state = .failed;
    }
}

// A successful backend reset is the only boundary that may retire an active
// asynchronous request without waiting for its physical completion. The
// backend promises that old commands can no longer touch buffers before the
// callback returns; handles are invalidated before waiters or slots are freed.
pub fn reset(index: usize, reason: u32) bool {
    var pin = pinDevice(index) orelse return false;
    defer unpinDevice(&pin);
    const device = pin.device;
    const reset_fn = device.async_reset_fn orelse return false;

    var active: [MAX_REQUEST_QUEUE_DEPTH]RequestExecution = undefined;
    var cancel_needed: [MAX_REQUEST_QUEUE_DEPTH]bool = .{false} ** MAX_REQUEST_QUEUE_DEPTH;
    var active_count: usize = 0;
    const locked = lockDevice(device);
    if (device.resetting) {
        unlockDevice(device, locked);
        return false;
    }
    device.resetting = true;
    device.state = .recovering;
    for (&device.request_slots, 0..) |*slot, slot_index| {
        switch (slot.state) {
            .queued => {
                slot.state = .completed;
                slot.ok = false;
                slot.err = .reset;
                slot.complete_tick = timer.tickCount();
                recordRequestFailure(device, slot.kind, .reset);
            },
            .active => {
                if (slot.completion_override == .none) slot.completion_override = .reset;
                const first_cancel = !slot.cancel_requested;
                slot.cancel_requested = true;
                if (active_count < active.len) {
                    active[active_count] = executionFromSlot(slot_index, slot.*);
                    cancel_needed[active_count] = first_cancel;
                    active_count += 1;
                }
            },
            .free, .completed => {},
        }
    }
    _ = device.completion_available.wakeAll();
    unlockDevice(device, locked);

    var cancel_index: usize = 0;
    while (cancel_index < active_count) : (cancel_index += 1) {
        if (cancel_needed[cancel_index]) {
            requestBackendCancel(device, active[cancel_index], CANCEL_REASON_RESET);
        }
    }
    device.stats.async_resets +%= 1;
    runtime_summary.async_resets +%= 1;
    if (reset_fn(device.ctx, reason) != 0) {
        const failed_locked = lockDevice(device);
        device.resetting = false;
        device.state = .failed;
        unlockDevice(device, failed_locked);
        return false;
    }

    var finish_index: usize = 0;
    while (finish_index < active_count) : (finish_index += 1) {
        forceCompleteAfterReset(device, active[finish_index]);
    }
    const finish_locked = lockDevice(device);
    device.resetting = false;
    device.state = if (device.active_executions == 0) .active else .busy;
    _ = device.slot_available.wakeAll();
    _ = device.completion_available.wakeAll();
    unlockDevice(device, finish_locked);
    return true;
}

fn forceCompleteAfterReset(device: *Device, original: RequestExecution) void {
    const locked = lockDevice(device);
    if (original.slot_index >= device.request_slots.len) {
        unlockDevice(device, locked);
        return;
    }
    const slot = &device.request_slots[original.slot_index];
    if (slot.state != .active or slot.id != original.id or slot.backend_handle != original.backend_handle) {
        unlockDevice(device, locked);
        return;
    }
    const request = executionFromSlot(original.slot_index, slot.*);
    unlockDevice(device, locked);
    finishRequest(device, request, false, .reset);
}

pub fn recordSense(index: usize, opcode: u8, key: u8, asc: u8, ascq: u8) void {
    var pin = pinDevice(index) orelse return;
    defer unpinDevice(&pin);
    const device = pin.device;
    device.stats.last_sense = .{
        .valid = true,
        .opcode = opcode,
        .key = key,
        .asc = asc,
        .ascq = ascq,
    };
}

pub fn busLabel(bus: Bus) []const u8 {
    return busName(bus);
}

pub fn stateLabel(state: State) []const u8 {
    return stateName(state);
}

pub fn errorLabel(err: Error) []const u8 {
    return errorName(err);
}

pub fn sourceLabel(source: Source) []const u8 {
    return sourceName(source);
}

pub fn read(index: usize, lba: u64, sectors: u16, out: []u8) bool {
    return readWithPolicy(index, lba, sectors, out, false);
}

/// Kernel-only direct I/O. The caller proves that `out` is resident,
/// owner-fixed and alive until this synchronous call returns. Unlike the
/// general API, an active timeout cannot detach this borrowed buffer.
pub fn readDirect(index: usize, lba: u64, sectors: u16, out: []u8) bool {
    return readWithPolicy(index, lba, sectors, out, true);
}

/// Test-profile-only, read-only proof that one canonical NVMe request crosses
/// the runtime block worker and asynchronous backend boundary. The NVME.R4D
/// emits the companion `[NVMEIRQ]` marker only after an MSI/MSI-X-triggered CQ
/// drain with no polling fallback.
pub fn nvmeInterruptAcceptanceProbe() bool {
    var device_index: usize = 0;
    while (device_index < maxDevices()) : (device_index += 1) {
        const device = get(device_index) orelse continue;
        if (device.bus != .nvme) continue;
        const sector_size: usize = @intCast(device.sector_size);
        if (sector_size == 0 or sector_size > 4096) return nvmeProbeFailure("sector-size");
        const before = snapshotDeviceStats(device_index) orelse return nvmeProbeFailure("stats-before");
        var sector: [4096]u8 align(64) = undefined;
        if (!readDirect(device_index, 0, 1, sector[0..sector_size])) return nvmeProbeFailure("read");
        const after = snapshotDeviceStats(device_index) orelse return nvmeProbeFailure("stats-after");
        const worker_requests = after.worker_requests -% before.worker_requests;
        const worker_completions = after.worker_completions -% before.worker_completions;
        const async_submissions = after.async_submissions -% before.async_submissions;
        const async_completions = after.async_completions -% before.async_completions;
        if (worker_requests == 0 or worker_completions == 0 or
            async_submissions == 0 or async_completions == 0 or
            after.timeout_failures != before.timeout_failures)
        {
            return nvmeProbeFailure("runtime-counters");
        }
        k.puts("[NVMEIRQPROBE] result=OK worker_requests=");
        k.putDec(worker_requests);
        k.puts(" worker_completions=");
        k.putDec(worker_completions);
        k.puts(" async_submissions=");
        k.putDec(async_submissions);
        k.puts(" async_completions=");
        k.putDec(async_completions);
        k.puts("\r\n");
        return true;
    }
    return nvmeProbeFailure("device-missing");
}

fn snapshotDeviceStats(index: usize) ?Stats {
    var pin = pinDevice(index) orelse return null;
    defer unpinDevice(&pin);
    const locked = lockDevice(pin.device);
    defer unlockDevice(pin.device, locked);
    return pin.device.stats;
}

fn nvmeProbeFailure(reason: []const u8) bool {
    k.puts("[NVMEIRQPROBE] result=FAILED reason=");
    k.puts(reason);
    k.puts("\r\n");
    return false;
}

fn readWithPolicy(index: usize, lba: u64, sectors: u16, out: []u8, trusted_resident: bool) bool {
    var pin = pinDevice(index) orelse return false;
    defer unpinDevice(&pin);
    const device = pin.device;
    if (validateRequest(device, lba, sectors, out.len)) |err| {
        recordReadFailure(device, err);
        return false;
    }
    var iterator = block_split.Iterator.init(sectors, device.max_sectors_per_request, device.sector_size) orelse {
        recordReadFailure(device, .invalid_request);
        return false;
    };
    while (iterator.next()) |chunk| {
        if (readChunk(
            device,
            lba + @as(u64, chunk.sector_offset),
            chunk.sectors,
            out[chunk.byte_offset .. chunk.byte_offset + chunk.byte_count],
            trusted_resident,
        ) != .none) return false;
    }
    return true;
}

fn readChunk(device: *Device, lba: u64, sectors: u16, out: []u8, trusted_resident: bool) Error {
    const byte_count = @as(usize, sectors) * @as(usize, device.sector_size);

    // The runtime block worker is a different task.  It must never retain a
    // raw pointer into the caller's pageable R4X address space: a page-out
    // between enqueue and execution would make the storage worker fault back
    // into the storage path it is meant to service.  Kernel-heap bounce
    // memory is non-pageable and remains owned by this synchronous call until
    // the exact request has completed.  Early boot still executes inline and
    // therefore needs no allocation.
    const use_runtime_worker = runtimeWorkerReady();
    const bounce = if (use_runtime_worker and !trusted_resident)
        heap.alloc(byte_count, 16) orelse {
            recordReadFailure(device, .busy);
            return .busy;
        }
    else
        null;
    var release_bounce = true;
    defer if (release_bounce) if (bounce) |memory| {
        _ = heap.free(memory);
    };
    const buffer_ownership: block_dispatch.BufferOwnership = if (!use_runtime_worker)
        .none
    else if (trusted_resident)
        .borrowed_resident
    else
        .bounce_owned;
    if (buffer_ownership == .borrowed_resident) {
        device.stats.direct_requests +%= 1;
        device.stats.direct_bytes +%= byte_count;
        runtime_summary.direct_requests +%= 1;
        runtime_summary.direct_bytes +%= byte_count;
    } else if (buffer_ownership == .bounce_owned) {
        device.stats.bounce_allocations +%= 1;
        device.stats.bounce_bytes +%= byte_count;
        runtime_summary.bounce_allocations +%= 1;
        runtime_summary.bounce_bytes +%= byte_count;
    }
    const request_buffer = if (bounce) |memory| memory.ptr else out.ptr;
    const request_id = enqueueRequest(device, .read, lba, sectors, request_buffer, null, byte_count, buffer_ownership) orelse {
        const err = device.stats.last_error;
        recordReadFailure(device, err);
        return err;
    };
    scheduleDeviceQueue(device, use_runtime_worker);
    const result = waitForRequest(device, request_id, requestTimeout(device));
    if (result.buffer_detached) release_bounce = false;
    if (!result.ok) return result.err;
    if (bounce) |memory| {
        @memcpy(out[0..byte_count], memory[0..byte_count]);
        device.stats.bounce_copy_bytes +%= byte_count;
        runtime_summary.bounce_copy_bytes +%= byte_count;
    }
    return .none;
}

pub fn write(index: usize, lba: u64, sectors: u16, data: []const u8) bool {
    const result = writeWithProgress(index, lba, sectors, data);
    return result.err == .none and result.sectors_completed == sectors;
}

pub fn writeWithProgress(index: usize, lba: u64, sectors: u16, data: []const u8) TransferResult {
    return writeWithProgressPolicy(index, lba, sectors, data, false);
}

/// Kernel-only direct I/O with the same resident, owner-fixed lifetime
/// requirement as readDirect.
pub fn writeDirect(index: usize, lba: u64, sectors: u16, data: []const u8) bool {
    const result = writeDirectWithProgress(index, lba, sectors, data);
    return result.err == .none and result.sectors_completed == sectors;
}

pub fn writeDirectWithProgress(index: usize, lba: u64, sectors: u16, data: []const u8) TransferResult {
    return writeWithProgressPolicy(index, lba, sectors, data, true);
}

fn writeWithProgressPolicy(index: usize, lba: u64, sectors: u16, data: []const u8, trusted_resident: bool) TransferResult {
    var pin = pinDevice(index) orelse return .{ .err = .invalid_request };
    defer unpinDevice(&pin);
    const device = pin.device;
    if ((device.write_fn == null and device.async_submit_fn == null) or !device.writable) {
        recordWriteFailure(device, .no_writer);
        return .{ .err = .no_writer };
    }
    if (validateRequest(device, lba, sectors, data.len)) |err| {
        recordWriteFailure(device, err);
        return .{ .err = err };
    }
    var iterator = block_split.Iterator.init(sectors, device.max_sectors_per_request, device.sector_size) orelse {
        recordWriteFailure(device, .invalid_request);
        return .{ .err = .invalid_request };
    };
    var completed: u16 = 0;
    while (iterator.next()) |chunk| {
        const err = writeChunk(
            device,
            lba + @as(u64, chunk.sector_offset),
            chunk.sectors,
            data[chunk.byte_offset .. chunk.byte_offset + chunk.byte_count],
            trusted_resident,
        );
        if (err != .none) return .{ .sectors_completed = completed, .err = err };
        completed += chunk.sectors;
    }
    return .{ .sectors_completed = completed };
}

fn writeChunk(device: *Device, lba: u64, sectors: u16, data: []const u8, trusted_resident: bool) Error {
    const byte_count = @as(usize, sectors) * @as(usize, device.sector_size);
    const use_runtime_worker = runtimeWorkerReady();
    const bounce = if (use_runtime_worker and !trusted_resident)
        heap.alloc(byte_count, 16) orelse {
            recordWriteFailure(device, .busy);
            return .busy;
        }
    else
        null;
    var release_bounce = true;
    defer if (release_bounce) if (bounce) |memory| {
        _ = heap.free(memory);
    };
    const buffer_ownership: block_dispatch.BufferOwnership = if (!use_runtime_worker)
        .none
    else if (trusted_resident)
        .borrowed_resident
    else
        .bounce_owned;
    if (buffer_ownership == .borrowed_resident) {
        device.stats.direct_requests +%= 1;
        device.stats.direct_bytes +%= byte_count;
        runtime_summary.direct_requests +%= 1;
        runtime_summary.direct_bytes +%= byte_count;
    } else if (buffer_ownership == .bounce_owned) {
        device.stats.bounce_allocations +%= 1;
        device.stats.bounce_bytes +%= byte_count;
        runtime_summary.bounce_allocations +%= 1;
        runtime_summary.bounce_bytes +%= byte_count;
    }
    if (bounce) |memory| {
        @memcpy(memory[0..byte_count], data[0..byte_count]);
        device.stats.bounce_copy_bytes +%= byte_count;
        runtime_summary.bounce_copy_bytes +%= byte_count;
    }
    const request_buffer = if (bounce) |memory| memory.ptr else data.ptr;
    const request_id = enqueueRequest(device, .write, lba, sectors, null, request_buffer, byte_count, buffer_ownership) orelse {
        const err = device.stats.last_error;
        recordWriteFailure(device, err);
        return err;
    };
    scheduleDeviceQueue(device, use_runtime_worker);
    const result = waitForRequest(device, request_id, requestTimeout(device));
    if (result.buffer_detached) release_bounce = false;
    return if (result.ok) .none else result.err;
}

pub fn flush(index: usize) bool {
    var pin = pinDevice(index) orelse return false;
    defer unpinDevice(&pin);
    const device = pin.device;
    if (device.flush_fn == null and device.async_submit_fn == null) return true;
    const request_id = enqueueRequest(device, .flush, 0, 0, null, null, 0, .none) orelse {
        recordFlushFailure(device, device.stats.last_error);
        return false;
    };
    scheduleDeviceQueue(device, runtimeWorkerReady());
    return waitForRequest(device, request_id, requestTimeout(device)).ok;
}

fn enqueueRequest(
    device: *Device,
    kind: RequestKind,
    lba: u64,
    sectors: u16,
    buffer: ?[*]u8,
    const_buffer: ?[*]const u8,
    buffer_len: usize,
    buffer_ownership: block_dispatch.BufferOwnership,
) ?u64 {
    const timeout = requestTimeout(device);
    const forever = timeout == sync.WAIT_FOREVER;
    const wait_start = timer.tickCount();
    const finite_deadline = if (forever) std.math.maxInt(u64) else timer.deadlineAfter(wait_start, timeout);
    while (true) {
        const locked = lockDevice(device);
        if (device.resetting) {
            unlockDevice(device, locked);
            recordQueueBackpressure(device, .busy);
            return null;
        }
        if (findFreeSlot(device)) |slot_index| {
            device.stats.next_request_id +%= 1;
            const id = device.stats.next_request_id;
            device.request_slots[slot_index] = .{
                .state = .queued,
                .id = id,
                .kind = kind,
                .lba = lba,
                .sectors = sectors,
                .buffer = buffer,
                .const_buffer = const_buffer,
                .buffer_len = buffer_len,
                .buffer_ownership = buffer_ownership,
                .submit_tick = timer.tickCount(),
            };
            device.stats.queued_requests +%= 1;
            updateQueueHighWater(device);
            unlockDevice(device, locked);
            return id;
        }

        device.stats.queue_full_waits +%= 1;
        unlockDevice(device, locked);
        if (!canBlockOnStorage()) {
            recordQueueBackpressure(device, .busy);
            return null;
        }

        const now = timer.tickCount();
        if (!forever and now >= finite_deadline) {
            recordQueueBackpressure(device, .timeout);
            return null;
        }
        // A wake for a competing submitter must not restart this request's
        // relative timeout. Wait only the remaining absolute admission budget.
        const remaining = if (forever) sync.WAIT_FOREVER else finite_deadline - now;
        const wait_result = device.slot_available.wait(remaining, "block-slot");
        if (wait_result == .signaled) continue;
        recordQueueBackpressure(device, switch (wait_result) {
            .timeout => .timeout,
            .cancelled, .killed, .failed => .cancelled,
            else => .busy,
        });
        return null;
    }
}

fn scheduleDeviceQueue(device: *Device, use_runtime_worker: bool) void {
    // The caller chooses the execution owner before publishing any buffer.
    // Re-checking here could switch an unbounced early-boot pointer to the
    // asynchronous worker if that worker became live between enqueue/wake.
    if (use_runtime_worker) {
        runtime_summary.worker_wakeups +%= 1;
        const lane = effectiveWorkerLane(device.controller_lane);
        if (lane != block_dispatch.no_lane) {
            controller_runtime[lane].event.signal();
            return;
        }
        // A worker disappearing between admission and publication is rare,
        // but the request still owns a safe resident/bounce buffer. Execute
        // it synchronously instead of stranding the queue.
        _ = pumpDeviceQueue(device, .boot_inline);
        return;
    }

    _ = pumpDeviceQueue(device, .boot_inline);
}

fn pumpDeviceQueue(device: *Device, mode: ExecutionMode) bool {
    var did_work = false;
    while (true) {
        if (takeReadyCompletion(device)) |ready| {
            did_work = true;
            const result = classifyAsyncCompletion(ready.request, ready.completion);
            finishRequest(device, ready.request, result.ok, result.err);
            continue;
        }
        const request = beginNextRequest(device, mode) orelse break;
        did_work = true;
        // Preload storage is registered and scanned before the scheduler and
        // controller workers exist. A v2 backend therefore keeps its v1
        // callbacks as the bounded boot fallback and switches to nonblocking
        // submit only on the runtime worker. This permits one canonical
        // descriptor to remain bootable and become parallel later.
        if (useAsyncSubmission(mode, device.async_submit_fn != null)) if (device.async_submit_fn) |submit| {
            submitAsyncRequest(device, request, submit);
            continue;
        };
        const result = executeRequest(device, request);
        finishRequest(device, request, result.ok, result.err);
    }
    return did_work;
}

const ReadyCompletion = struct {
    request: RequestExecution,
    completion: block_dispatch.Completion,
};

fn takeReadyCompletion(device: *Device) ?ReadyCompletion {
    const locked = lockDevice(device);
    var index: usize = 0;
    while (index < device.request_slots.len) : (index += 1) {
        const slot = &device.request_slots[index];
        if (slot.state != .active or slot.backend_handle == 0) continue;
        const irq_flags = owner_locks.storage.acquire();
        const completion = slot.completion_latch.take();
        owner_locks.storage.release(irq_flags);
        if (completion) |value| {
            const request = executionFromSlot(index, slot.*);
            unlockDevice(device, locked);
            return .{ .request = request, .completion = value };
        }
    }
    unlockDevice(device, locked);
    return null;
}

fn submitAsyncRequest(device: *Device, request: RequestExecution, submit: AsyncSubmitFn) void {
    device.stats.async_submissions +%= 1;
    runtime_summary.async_submissions +%= 1;
    const public_request = AsyncRequest{
        .handle = request.backend_handle,
        .kind = request.kind,
        .lba = request.lba,
        .sectors = request.sectors,
        .buffer = request.buffer,
        .const_buffer = request.const_buffer,
        .buffer_len = request.buffer_len,
        .complete = asyncBackendComplete,
    };
    const unwind = task_context.enterUnwind();
    if (!unwind.admitted()) {
        finishRequest(device, request, false, .busy);
        return;
    }
    defer _ = task_context.leaveUnwind(unwind);
    const submit_result = submit(device.ctx, &public_request);
    if (submit_result == 0) return;

    // A backend may complete inline before returning. Completion owns the
    // terminal result in that race; otherwise the nonzero submit result means
    // hardware never acquired the request or its buffer.
    const irq_flags = owner_locks.storage.acquire();
    const rejected = if (request.slot_index < device.request_slots.len)
        device.request_slots[request.slot_index].completion_latch.rejectSubmission(request.backend_handle)
    else
        false;
    owner_locks.storage.release(irq_flags);
    if (!rejected) return;
    finishRequest(device, request, false, if (submit_result > 0) .busy else backendErrorForKind(request.kind));
}

fn classifyAsyncCompletion(request: RequestExecution, completion: block_dispatch.Completion) RequestResult {
    if (completion.result == ASYNC_RESULT_OK) {
        const expected: u32 = switch (request.kind) {
            .read, .write => @intCast(request.buffer_len),
            .flush, .none => 0,
        };
        if (completion.bytes == expected) return .{ .ok = true };
        return .{ .err = backendErrorForKind(request.kind) };
    }
    return .{ .err = switch (completion.result) {
        ASYNC_RESULT_CANCELLED => .cancelled,
        ASYNC_RESULT_TIMEOUT => .timeout,
        ASYNC_RESULT_RESET => .reset,
        ASYNC_RESULT_SHUTDOWN => .shutdown,
        else => backendErrorForKind(request.kind),
    } };
}

fn backendErrorForKind(kind: RequestKind) Error {
    return switch (kind) {
        .read => .backend_read,
        .write => .backend_write,
        .flush => .backend_flush,
        .none => .invalid_request,
    };
}

fn beginNextRequest(device: *Device, mode: ExecutionMode) ?RequestExecution {
    const locked = lockDevice(device);
    const slot_index = findQueuedSlot(device) orelse {
        unlockDevice(device, locked);
        return null;
    };
    const queued = &device.request_slots[slot_index];
    if (device.resetting or !block_dispatch.submissionAllowed(
        device.active_executions,
        device.queue_depth,
        queued.kind == .flush,
        hasActiveFlush(device),
    )) {
        unlockDevice(device, locked);
        return null;
    }
    const start_tick = timer.tickCount();
    var slot = &device.request_slots[slot_index];
    slot.state = .active;
    slot.start_tick = start_tick;
    slot.execution_mode = mode;
    if (useAsyncSubmission(mode, device.async_submit_fn != null)) {
        slot.backend_handle = nextBackendHandle(device.slot_index, slot_index);
        if (!slot.completion_latch.activate(slot.backend_handle)) {
            slot.state = .queued;
            slot.backend_handle = 0;
            unlockDevice(device, locked);
            return null;
        }
    }
    device.active_executions +|= 1;
    if (device.active_executions > device.stats.in_flight_high_water) {
        device.stats.in_flight_high_water = device.active_executions;
    }
    runtime_summary.in_flight +|= 1;
    if (runtime_summary.in_flight > runtime_summary.in_flight_high_water) {
        runtime_summary.in_flight_high_water = runtime_summary.in_flight;
    }
    device.stats.dequeued_requests +%= 1;
    device.stats.active_request = snapshotFromSlot(slot.*);
    device.state = .busy;
    const request = RequestExecution{
        .slot_index = slot_index,
        .id = slot.id,
        .kind = slot.kind,
        .lba = slot.lba,
        .sectors = slot.sectors,
        .buffer = slot.buffer,
        .const_buffer = slot.const_buffer,
        .buffer_len = slot.buffer_len,
        .buffer_ownership = slot.buffer_ownership,
        .start_tick = start_tick,
        .mode = mode,
        .backend_handle = slot.backend_handle,
    };
    switch (mode) {
        .boot_inline => {
            device.stats.boot_inline_requests +%= 1;
            runtime_summary.boot_inline_requests +%= 1;
        },
        .runtime_worker => {
            device.stats.worker_requests +%= 1;
            runtime_summary.worker_runtime_requests +%= 1;
            runtime_summary.worker_parallel_active +|= 1;
            if (runtime_summary.worker_parallel_active > runtime_summary.worker_parallel_active_max) {
                runtime_summary.worker_parallel_active_max = runtime_summary.worker_parallel_active;
            }
        },
    }
    unlockDevice(device, locked);
    return request;
}

fn useAsyncSubmission(mode: ExecutionMode, has_submit: bool) bool {
    return has_submit and mode == .runtime_worker;
}

fn executionFromSlot(slot_index: usize, slot: RequestSlot) RequestExecution {
    return .{
        .slot_index = slot_index,
        .id = slot.id,
        .kind = slot.kind,
        .lba = slot.lba,
        .sectors = slot.sectors,
        .buffer = slot.buffer,
        .const_buffer = slot.const_buffer,
        .buffer_len = slot.buffer_len,
        .buffer_ownership = slot.buffer_ownership,
        .start_tick = slot.start_tick,
        .mode = slot.execution_mode,
        .backend_handle = slot.backend_handle,
    };
}

fn hasActiveFlush(device: *const Device) bool {
    for (device.request_slots) |slot| {
        if (slot.state == .active and slot.kind == .flush) return true;
    }
    return false;
}

fn nextBackendHandle(device_index: u8, request_slot: usize) u64 {
    next_backend_handle_sequence = (next_backend_handle_sequence +% 1) & 0x0000_FFFF_FFFF_FFFF;
    if (next_backend_handle_sequence == 0) next_backend_handle_sequence = 1;
    return (next_backend_handle_sequence << 16) |
        (@as(u64, device_index) + 1) << 8 |
        (@as(u64, @intCast(request_slot)) + 1);
}

pub fn asyncBackendComplete(handle: u64, result: i32, bytes: u32) callconv(.c) void {
    const encoded_request = handle & 0xFF;
    const encoded_device = (handle >> 8) & 0xFF;
    if (encoded_request == 0 or encoded_device == 0) {
        runtime_summary.late_completions +%= 1;
        return;
    }
    const request_slot: usize = @intCast(encoded_request - 1);
    const device_index: usize = @intCast(encoded_device - 1);
    if (device_index >= devices.len or request_slot >= MAX_REQUEST_QUEUE_DEPTH) {
        runtime_summary.late_completions +%= 1;
        return;
    }

    const irq_flags = owner_locks.storage.acquire();
    const device_slot = &devices[device_index];
    if (!device_slot.used) {
        runtime_summary.late_completions +%= 1;
        owner_locks.storage.release(irq_flags);
        return;
    }
    const device = &device_slot.device;
    const slot = &device.request_slots[request_slot];
    if (slot.state != .active or slot.backend_handle != handle) {
        device.stats.late_completions +%= 1;
        runtime_summary.late_completions +%= 1;
        owner_locks.storage.release(irq_flags);
        return;
    }
    if (!slot.completion_latch.publish(handle, result, bytes)) {
        device.stats.duplicate_completions +%= 1;
        runtime_summary.duplicate_completions +%= 1;
        owner_locks.storage.release(irq_flags);
        return;
    }
    const lane = effectiveWorkerLane(device.controller_lane);
    owner_locks.storage.release(irq_flags);
    if (lane != block_dispatch.no_lane) {
        runtime_summary.worker_wakeups +%= 1;
        controller_runtime[lane].event.signal();
    }
}

fn executeRequest(device: *Device, request: RequestExecution) RequestResult {
    const unwind = task_context.enterUnwind();
    if (!unwind.admitted()) return .{ .err = .busy };
    defer _ = task_context.leaveUnwind(unwind);
    switch (request.kind) {
        .read => {
            const out_ptr = request.buffer orelse return .{ .err = .buffer_too_small };
            const ok = device.read_fn(device.ctx, request.lba, request.sectors, out_ptr[0..request.buffer_len]);
            return .{ .ok = ok, .err = if (ok) .none else .backend_read };
        },
        .write => {
            const write_fn = device.write_fn orelse return .{ .err = .no_writer };
            const data_ptr = request.const_buffer orelse return .{ .err = .buffer_too_small };
            const ok = write_fn(device.ctx, request.lba, request.sectors, data_ptr[0..request.buffer_len]);
            return .{ .ok = ok, .err = if (ok) .none else .backend_write };
        },
        .flush => {
            const flush_fn = device.flush_fn orelse return .{ .ok = true };
            const ok = flush_fn(device.ctx);
            return .{ .ok = ok, .err = if (ok) .none else .backend_flush };
        },
        .none => return .{ .err = .invalid_request },
    }
}

fn finishRequest(device: *Device, request: RequestExecution, ok: bool, err: Error) void {
    var detached_buffer: ?[]u8 = null;
    const locked = lockDevice(device);
    if (request.slot_index >= effectiveQueueDepth(device)) {
        unlockDevice(device, locked);
        return;
    }
    var slot = &device.request_slots[request.slot_index];
    if (slot.id != request.id or slot.state != .active or
        (request.backend_handle != 0 and slot.backend_handle != request.backend_handle))
    {
        unlockDevice(device, locked);
        return;
    }
    const irq_flags = owner_locks.storage.acquire();
    slot.completion_latch.invalidate();
    owner_locks.storage.release(irq_flags);
    // Only the exact live execution owns one active count. A stale or double
    // completion must not make quiescence visible while real I/O still runs.
    if (device.active_executions != 0) device.active_executions -= 1;
    if (runtime_summary.in_flight != 0) runtime_summary.in_flight -= 1;
    const complete_tick = timer.tickCount();
    const latency = if (complete_tick >= request.start_tick) complete_tick - request.start_tick else 0;
    const completion_override = slot.completion_override;
    const caller_detached = slot.caller_detached;
    if (caller_detached and slot.buffer_ownership == .bounce_owned) {
        detached_buffer = switch (request.kind) {
            .read => if (request.buffer) |ptr| ptr[0..request.buffer_len] else null,
            .write => if (request.const_buffer) |ptr| @constCast(ptr[0..request.buffer_len]) else null,
            else => null,
        };
    }
    slot.state = .completed;
    slot.ok = if (completion_override != .none) false else ok;
    slot.err = if (completion_override != .none) completion_override else err;
    slot.complete_tick = complete_tick;
    device.stats.last_request = snapshotFromSlot(slot.*);
    device.stats.active_request = oldestActiveSnapshot(device, request.slot_index);
    device.stats.completion_last_ticks = latency;
    device.stats.completion_total_ticks +%= latency;
    if (latency > device.stats.completion_max_ticks) device.stats.completion_max_ticks = latency;
    if (completion_override != .none) {
        if (!caller_detached) recordRequestFailure(device, request.kind, completion_override);
    } else if (ok) {
        recordRequestSuccess(device, request.kind, request.sectors);
    } else {
        recordRequestFailure(device, request.kind, err);
    }
    if (request.backend_handle != 0) {
        device.stats.async_completions +%= 1;
        runtime_summary.async_completions +%= 1;
    }
    if (!caller_detached) {
        _ = device.completion_available.wakeAll();
        device.stats.completion_signals +%= 1;
        runtime_summary.completion_signals +%= 1;
    }
    switch (request.mode) {
        .boot_inline => {
            device.stats.boot_inline_completions +%= 1;
            runtime_summary.boot_inline_completions +%= 1;
        },
        .runtime_worker => {
            device.stats.worker_completions +%= 1;
            runtime_summary.worker_runtime_completions +%= 1;
            if (runtime_summary.worker_parallel_active != 0) {
                runtime_summary.worker_parallel_active -= 1;
            }
        },
    }
    if (caller_detached) {
        slot.* = .{};
        _ = device.slot_available.wakeOne();
    }
    unlockDevice(device, locked);
    if (detached_buffer) |memory| _ = heap.free(memory);
}

// Storage-wait watchdog (0.60.20): a device registered without a timeout
// used to park the requester with WAIT_FOREVER.  A single wedged request
// (worker stuck in the driver, lost completion) then froze the whole
// system, because the requester holds the FS request path while it sleeps.
// Now every wait runs in bounded observation slices.  A queued request can
// be cancelled safely when its caller timeout expires.  An active runtime
// request with a bounce buffer detaches its caller: the worker frees that
// buffer only after the backend callback returns. A trusted direct request
// cannot detach its borrowed resident buffer, so its owner waits for physical
// completion after the timeout has been classified. WAIT_FOREVER remains an
// ownership-safe forever wait and keeps the backed-off reports.
const WATCHDOG_SLICE_TICKS: u64 = 5 * @as(u64, timer.DEFAULT_HZ);

fn shouldReportWatchdogSlice(slices: u32) bool {
    return slices == 1 or (slices & (slices - 1)) == 0;
}

fn watchdogReport(
    device: *Device,
    request_id: u64,
    slices: u32,
    incident_token: *diag_screen.IncidentToken,
) void {
    // COM1/LOGSVC may be unreachable (LOGSVC itself needs storage), so paint
    // straight to the framebuffer. Do not enter crash mode merely because a
    // slow removable device crossed one observation slice.
    // First line BEFORE taking the device lock: if the queue lock itself is
    // wedged, at least the stall marker reaches the framebuffer.
    if (!incident_token.*.valid()) {
        incident_token.* = diag_screen.beginResolvableIncident();
    }
    diag_screen.write("[BLOCK] stall dev=");
    diag_screen.write(device.name);
    diag_screen.write(" slice=");
    diag_screen.writeDec(slices);
    diag_screen.endLine();
    k.puts("[BLOCK] watchdog: stall dev=");
    k.puts(device.name);
    k.puts(" slice=");
    putDec(slices);
    k.puts("\n");
    var snapshot: RequestSlot = .{};
    var have_slot = false;
    const locked = device.queue_lock.tryLock();
    if (locked) {
        if (findSlotById(device, request_id)) |slot_index| {
            snapshot = device.request_slots[slot_index];
            have_slot = true;
        }
    }
    const dev_state = device.state;
    unlockDevice(device, locked);

    diag_screen.write("[BLOCK] request dev=");
    diag_screen.write(device.name);
    diag_screen.write(" state=");
    diag_screen.write(@tagName(dev_state));
    if (!locked) {
        diag_screen.write(" queue_lock=busy");
    } else if (have_slot) {
        diag_screen.write(" req=");
        diag_screen.write(@tagName(snapshot.kind));
        diag_screen.write(" slot=");
        diag_screen.write(@tagName(snapshot.state));
        diag_screen.write(" lba=");
        diag_screen.writeDec(snapshot.lba);
        diag_screen.write(" sectors=");
        diag_screen.writeDec(snapshot.sectors);
    } else {
        diag_screen.write(" req=unknown");
    }
    diag_screen.endLine();

    k.puts("[BLOCK] watchdog: request stalled dev=");
    k.puts(device.name);
    k.puts(" driver=");
    k.puts(device.driver);
    k.puts(" state=");
    k.puts(@tagName(dev_state));
    k.puts(" slice=");
    putDec(slices);
    if (have_slot) {
        k.puts(" req=");
        k.puts(@tagName(snapshot.kind));
        k.puts(" slot=");
        k.puts(@tagName(snapshot.state));
        k.puts(" lba=");
        putDec(snapshot.lba);
        k.puts(" sectors=");
        putDec(snapshot.sectors);
        k.puts(" submit_tick=");
        putDec(snapshot.submit_tick);
        k.puts(" start_tick=");
        putDec(snapshot.start_tick);
        k.puts(" now=");
        putDec(timer.tickCount());
    } else {
        k.puts(" req=unknown");
    }
    k.puts("\n");
}

/// Deadman probe (0.60.20): is any request slot executing in a driver
/// callback for longer than `threshold` ticks?  The runtime worker calls
/// the driver synchronously; a slot that stays .active that long means the
/// worker is stuck (or spinning) INSIDE the driver -- invisible to
/// blocked-task scans.  Racy read-only scan, crash-class trigger only.
pub fn hasStalledExecution(now: u64, threshold: u64) bool {
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        const slot_entry = &devices[index];
        if (!slot_entry.used) continue;
        const device = &slot_entry.device;
        for (device.request_slots) |slot| {
            if (slot.state != .active) continue;
            if (now < slot.start_tick) continue;
            if (now - slot.start_tick > threshold) return true;
        }
    }
    return false;
}

/// Framebuffer-direct variant of dumpStalledExecutions (0.60.20).
pub fn dumpStalledToDiag(now: u64, threshold: u64) void {
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        const slot_entry = &devices[index];
        if (!slot_entry.used) continue;
        const device = &slot_entry.device;
        for (device.request_slots) |slot| {
            if (slot.state != .active) continue;
            if (now < slot.start_tick or now - slot.start_tick <= threshold) continue;
            diag_screen.write("[BLOCK] stalled exec dev=");
            diag_screen.write(device.name);
            diag_screen.write(" drv=");
            diag_screen.write(device.driver);
            diag_screen.write(" req=");
            diag_screen.write(@tagName(slot.kind));
            diag_screen.write(" lba=");
            diag_screen.writeDec(slot.lba);
            diag_screen.write(" active_for=");
            diag_screen.writeDec(now - slot.start_tick);
            diag_screen.endLine();
        }
    }
}

/// Paints every stalled execution (see hasStalledExecution) to the log.
pub fn dumpStalledExecutions(now: u64, threshold: u64) void {
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        const slot_entry = &devices[index];
        if (!slot_entry.used) continue;
        const device = &slot_entry.device;
        for (device.request_slots) |slot| {
            if (slot.state != .active) continue;
            if (now < slot.start_tick or now - slot.start_tick <= threshold) continue;
            k.puts("[BLOCK] stalled execution dev=");
            k.puts(device.name);
            k.puts(" driver=");
            k.puts(device.driver);
            k.puts(" req=");
            k.puts(@tagName(slot.kind));
            k.puts(" lba=");
            putDec(slot.lba);
            k.puts(" sectors=");
            putDec(slot.sectors);
            k.puts(" active_for=");
            putDec(now - slot.start_tick);
            k.puts(" ticks\r\n");
        }
    }
}

fn putDec(value: u64) void {
    var digits: [20]u8 = undefined;
    if (value == 0) {
        k.puts("0");
        return;
    }
    var n = value;
    var i: usize = digits.len;
    while (n > 0) : (n /= 10) {
        i -= 1;
        digits[i] = '0' + @as(u8, @intCast(n % 10));
    }
    k.puts(digits[i..]);
}

fn waitForRequest(device: *Device, request_id: u64, timeout: u64) RequestResult {
    var counted_wait = false;
    var watchdog_slices: u32 = 0;
    var incident_token: diag_screen.IncidentToken = .{};
    defer if (incident_token.valid()) {
        // Success and classified failure both end this reporter's lifetime.
        // resolveIncident retains the evidence but prevents an abandoned
        // token from suppressing every later storage diagnosis.
        _ = diag_screen.resolveIncident(incident_token);
    };
    const forever = timeout == sync.WAIT_FOREVER;
    const wait_start = timer.tickCount();
    const finite_deadline = if (forever) std.math.maxInt(u64) else timer.deadlineAfter(wait_start, timeout);
    while (true) {
        const locked = lockDevice(device);
        const slot_index = findSlotById(device, request_id) orelse {
            unlockDevice(device, locked);
            return .{ .err = .invalid_request };
        };
        if (!counted_wait) {
            device.stats.completion_waits +%= 1;
            counted_wait = true;
        }
        const slot = &device.request_slots[slot_index];
        if (slot.state == .completed) {
            const result = RequestResult{ .ok = slot.ok, .err = slot.err };
            device.request_slots[slot_index] = .{};
            _ = device.slot_available.wakeOne();
            unlockDevice(device, locked);
            return result;
        }
        unlockDevice(device, locked);

        if (!canBlockOnStorage()) {
            _ = pumpDeviceQueue(device, .boot_inline);
            continue;
        }

        if (forever) {
            const wait_result = device.completion_available.wait(WATCHDOG_SLICE_TICKS, "block-completion");
            if (wait_result == .signaled) continue;
            if (wait_result == .cancelled or wait_result == .killed or wait_result == .failed) {
                switch (requestAbort(device, request_id, .cancelled, CANCEL_REASON_CALLER)) {
                    .retry => continue,
                    .done => |result| return result,
                    .wait_for_completion => {},
                }
            }
            watchdog_slices += 1;
            if (shouldReportWatchdogSlice(watchdog_slices)) {
                watchdogReport(device, request_id, watchdog_slices, &incident_token);
            }
            continue;
        }
        // A foreign completion wakeup must not restart the caller's entire
        // timeout.  Every pass waits only the remaining absolute budget.
        const now = timer.tickCount();
        var wait_result: sync.WaitResult = .timeout;
        if (now < finite_deadline) {
            wait_result = device.completion_available.wait(finite_deadline - now, "block-completion");
            if (wait_result == .signaled) continue;
        }
        const abort_error: Error = if (wait_result == .cancelled or wait_result == .killed or wait_result == .failed)
            .cancelled
        else
            .timeout;
        const abort_reason = if (abort_error == .timeout) CANCEL_REASON_TIMEOUT else CANCEL_REASON_CALLER;
        switch (requestAbort(device, request_id, abort_error, abort_reason)) {
            .retry => continue,
            .done => |result| return result,
            .wait_for_completion => {
                watchdog_slices += 1;
                if (shouldReportWatchdogSlice(watchdog_slices)) {
                    watchdogReport(device, request_id, watchdog_slices, &incident_token);
                }
                _ = device.completion_available.wait(WATCHDOG_SLICE_TICKS, "block-direct-completion");
                continue;
            },
        }
    }
}

const AbortDisposition = union(enum) {
    retry,
    wait_for_completion,
    done: RequestResult,
};

fn requestAbort(device: *Device, request_id: u64, abort_error: Error, reason: u32) AbortDisposition {
    const locked = lockDevice(device);
    const slot_index = findSlotById(device, request_id) orelse {
        if (abort_error == .timeout) {
            device.stats.timeout_failures +%= 1;
            device.stats.completion_timeouts +%= 1;
        }
        device.stats.last_error = abort_error;
        unlockDevice(device, locked);
        return .{ .done = .{ .err = abort_error } };
    };
    var slot = &device.request_slots[slot_index];
    switch (slot.state) {
        .queued => {
            recordRequestFailure(device, slot.kind, abort_error);
            if (abort_error == .timeout) device.stats.completion_timeouts +%= 1;
            slot.* = .{};
            _ = device.slot_available.wakeOne();
            unlockDevice(device, locked);
            return .{ .done = .{ .err = abort_error } };
        },
        .completed => {
            unlockDevice(device, locked);
            return .retry;
        },
        .active => {
            const first_abort = slot.completion_override == .none;
            if (first_abort) slot.completion_override = abort_error;
            const first_timeout = abort_error == .timeout and !slot.timeout_requested;
            if (first_timeout) {
                slot.timeout_requested = true;
                device.stats.completion_timeouts +%= 1;
            }
            const first_cancel = !slot.cancel_requested;
            if (first_cancel) slot.cancel_requested = true;
            const request = executionFromSlot(slot_index, slot.*);
            const action = block_dispatch.activeTimeoutAction(slot.buffer_ownership);
            if (action == .wait_for_completion) {
                if (first_timeout) {
                    device.stats.direct_timeout_waits +%= 1;
                    runtime_summary.direct_timeout_waits +%= 1;
                }
                unlockDevice(device, locked);
                if (first_cancel) requestBackendCancel(device, request, reason);
                return .wait_for_completion;
            }

            const first_detach = !slot.caller_detached;
            slot.caller_detached = true;
            if (first_detach) recordRequestFailure(device, slot.kind, abort_error);
            const buffer_detached = action == .detach_with_buffer;
            unlockDevice(device, locked);
            if (first_cancel) requestBackendCancel(device, request, reason);
            return .{ .done = .{ .err = abort_error, .buffer_detached = buffer_detached } };
        },
        .free => {
            unlockDevice(device, locked);
            return .{ .done = .{ .err = abort_error } };
        },
    }
}

fn requestBackendCancel(device: *Device, request: RequestExecution, reason: u32) void {
    if (request.backend_handle == 0) return;
    const cancel = device.async_cancel_fn orelse return;
    device.stats.async_cancel_requests +%= 1;
    runtime_summary.async_cancel_requests +%= 1;
    _ = cancel(device.ctx, request.backend_handle, reason);
}

fn recordRequestSuccess(device: *Device, kind: RequestKind, sectors: u16) void {
    device.stats.last_error = .none;
    device.stats.completions += 1;
    device.state = if (device.active_executions != 0) .busy else .active;
    switch (kind) {
        .read => {
            device.stats.read_ops += 1;
            device.stats.read_sectors += sectors;
        },
        .write => {
            device.stats.write_ops += 1;
            device.stats.write_sectors += sectors;
        },
        .flush => device.stats.flush_ops += 1,
        .none => {},
    }
}

fn recordRequestFailure(device: *Device, kind: RequestKind, err: Error) void {
    device.stats.last_error = err;
    if (err == .timeout) device.stats.timeout_failures += 1;
    device.state = if (device.active_executions != 0) .busy else .failed;
    switch (kind) {
        .read => device.stats.read_failures += 1,
        .write => device.stats.write_failures += 1,
        .flush => device.stats.flush_failures += 1,
        .none => {},
    }
}

fn recordQueueBackpressure(device: *Device, err: Error) void {
    const locked = lockDevice(device);
    device.stats.queue_full_rejections +%= 1;
    device.stats.busy_rejections +%= 1;
    if (err == .timeout) device.stats.timeout_failures +%= 1;
    device.stats.last_error = err;
    unlockDevice(device, locked);
}

fn recordReadFailure(device: *Device, err: Error) void {
    device.stats.read_failures += 1;
    device.stats.last_error = err;
    if (err == .timeout) device.stats.timeout_failures += 1;
}

fn recordWriteFailure(device: *Device, err: Error) void {
    device.stats.write_failures += 1;
    device.stats.last_error = err;
    if (err == .timeout) device.stats.timeout_failures += 1;
}

fn recordFlushFailure(device: *Device, err: Error) void {
    device.stats.flush_failures += 1;
    device.stats.last_error = err;
    if (err == .timeout) device.stats.timeout_failures += 1;
}

fn validateRequest(device: *const Device, lba: u64, sectors: u16, bytes: usize) ?Error {
    if (sectors == 0) return .invalid_request;
    if (@as(u64, sectors) > std.math.maxInt(u64) - lba) return .out_of_range;
    if (bytes < @as(usize, sectors) * @as(usize, device.sector_size)) return .buffer_too_small;
    if (device.sector_count != 0) {
        if (lba >= device.sector_count) return .out_of_range;
        if (@as(u64, sectors) > device.sector_count - lba) return .out_of_range;
    }
    return null;
}

fn requestTimeout(device: *const Device) u64 {
    return if (device.timeout_ticks == 0) sync.WAIT_FOREVER else device.timeout_ticks;
}

fn effectiveQueueDepth(device: *const Device) usize {
    _ = device;
    return MAX_REQUEST_QUEUE_DEPTH;
}

fn findFreeSlot(device: *Device) ?usize {
    const limit = effectiveQueueDepth(device);
    var i: usize = 0;
    while (i < limit) : (i += 1) {
        if (device.request_slots[i].state == .free) return i;
    }
    return null;
}

fn findQueuedSlot(device: *Device) ?usize {
    const limit = effectiveQueueDepth(device);
    var selected: ?usize = null;
    var i: usize = 0;
    while (i < limit) : (i += 1) {
        if (device.request_slots[i].state != .queued) continue;
        if (selected == null or device.request_slots[i].id < device.request_slots[selected.?].id) {
            selected = i;
        }
    }
    return selected;
}

fn findSlotById(device: *Device, request_id: u64) ?usize {
    const limit = effectiveQueueDepth(device);
    var i: usize = 0;
    while (i < limit) : (i += 1) {
        if (device.request_slots[i].state != .free and device.request_slots[i].id == request_id) return i;
    }
    return null;
}

fn countUsedSlots(device: *const Device) u32 {
    const limit = effectiveQueueDepth(device);
    var used: u32 = 0;
    var i: usize = 0;
    while (i < limit) : (i += 1) {
        if (device.request_slots[i].state != .free) used += 1;
    }
    return used;
}

fn updateQueueHighWater(device: *Device) void {
    const used = countUsedSlots(device);
    if (used > device.stats.queue_high_water) device.stats.queue_high_water = used;
}

fn snapshotFromSlot(slot: RequestSlot) RequestSnapshot {
    return .{
        .id = slot.id,
        .kind = slot.kind,
        .lba = slot.lba,
        .sectors = slot.sectors,
    };
}

fn oldestActiveSnapshot(device: *const Device, excluding: usize) RequestSnapshot {
    var selected: ?RequestSlot = null;
    var index: usize = 0;
    while (index < device.request_slots.len) : (index += 1) {
        if (index == excluding) continue;
        const slot = device.request_slots[index];
        if (slot.state != .active) continue;
        if (selected == null or slot.id < selected.?.id) selected = slot;
    }
    return if (selected) |slot| snapshotFromSlot(slot) else .{};
}

fn lockDevice(device: *Device) bool {
    if (!canBlockOnStorage()) return false;
    // Bounded slices instead of a silent forever-wait (0.60.20): if the
    // queue lock is wedged, say so loudly every slice and keep trying.
    var slices: u32 = 0;
    var incident_token: diag_screen.IncidentToken = .{};
    while (true) {
        if (device.queue_lock.lock(WATCHDOG_SLICE_TICKS)) {
            if (incident_token.valid()) _ = diag_screen.resolveIncident(incident_token);
            return true;
        }
        slices += 1;
        if (!incident_token.valid()) {
            incident_token = diag_screen.beginResolvableIncident();
        }
        diag_screen.write("[BLOCK] queue-lock stall dev=");
        diag_screen.write(device.name);
        diag_screen.write(" slice=");
        diag_screen.writeDec(slices);
        diag_screen.endLine();
        k.puts("[BLOCK] queue-lock stall dev=");
        k.puts(device.name);
        k.puts(" slice=");
        putDec(slices);
        k.puts("\r\n");
    }
}

fn unlockDevice(device: *Device, locked: bool) void {
    if (locked) _ = device.queue_lock.unlock();
}

fn canBlockOnStorage() bool {
    return scheduler.currentId() != null;
}

fn workerMain() callconv(.c) void {
    var lane = currentWorkerLane();
    while (lane == block_dispatch.no_lane) {
        scheduler.yield();
        lane = currentWorkerLane();
    }
    while (true) {
        if (pumpControllerRuntimeQueues(lane)) continue;
        runtime_summary.worker_idle_waits +%= 1;
        _ = controller_runtime[lane].event.waitResult(scheduler.WAIT_FOREVER);
    }
}

fn currentWorkerLane() u8 {
    const current = scheduler.current() orelse return block_dispatch.no_lane;
    var lane: usize = 0;
    while (lane < controller_runtime.len) : (lane += 1) {
        const runtime = &controller_runtime[lane];
        if (runtime.worker_started and
            runtime.worker_task_id == current.id and
            runtime.worker_task_generation == current.generation)
        {
            return @intCast(lane);
        }
    }
    return block_dispatch.no_lane;
}

fn effectiveWorkerLane(controller_lane: u8) u8 {
    if (controllerWorkerAlive(controller_lane)) return controller_lane;
    if (controllerWorkerAlive(primary_controller_lane)) return primary_controller_lane;
    return block_dispatch.no_lane;
}

fn pumpControllerRuntimeQueues(worker_lane: u8) bool {
    runtime_summary.worker_queue_scans +%= 1;
    var did_work = false;
    var index: usize = 0;
    while (index < device_slot_count) : (index += 1) {
        const flags = owner_locks.storage.acquire();
        const reference: ?access.DeviceRef = if (devices[index].used and !devices[index].retiring and
            effectiveWorkerLane(devices[index].device.controller_lane) == worker_lane)
            devices[index].device.access_ref
        else
            null;
        owner_locks.storage.release(flags);
        if (reference) |ref| if (pumpRuntimeDevice(ref)) {
            did_work = true;
        };
    }
    if (did_work) runtime_summary.worker_runs +%= 1;
    return did_work;
}

fn pumpRuntimeDevice(reference: access.DeviceRef) bool {
    var pin = pinDeviceExpected(reference.slot, reference, true) orelse return false;
    defer unpinDevice(&pin);
    return pumpDeviceQueue(pin.device, .runtime_worker);
}

// Boot-option-gated runtime acceptance for controller ownership. A deliberately
// blocked callback on one synthetic controller must not hold up a request on
// another controller. Static buffers also exercise the borrowed-resident path
// and prove that this path performs neither a bounce allocation nor a copy.
var dispatch_test_slow_entered = sync.EventV2.initMode(false, .auto_reset);
var dispatch_test_slow_release = sync.EventV2.initMode(false, .auto_reset);
var dispatch_test_slow_done = sync.EventV2.initMode(false, .auto_reset);
var dispatch_test_fast_done = sync.EventV2.initMode(false, .auto_reset);
var dispatch_test_slow_index: usize = 0;
var dispatch_test_fast_index: usize = 0;
var dispatch_test_slow_ok = false;
var dispatch_test_fast_ok = false;
var dispatch_test_slow_buffer: [512]u8 = .{0} ** 512;
var dispatch_test_fast_buffer: [512]u8 = .{0} ** 512;

pub fn parallelDispatchSelfTest() bool {
    if (!runtimeWorkerReady()) return dispatchSelfTestResult(false, .{}, .{});
    dispatch_test_slow_entered = sync.EventV2.initMode(false, .auto_reset);
    dispatch_test_slow_release = sync.EventV2.initMode(false, .auto_reset);
    dispatch_test_slow_done = sync.EventV2.initMode(false, .auto_reset);
    dispatch_test_fast_done = sync.EventV2.initMode(false, .auto_reset);
    dispatch_test_slow_ok = false;
    dispatch_test_fast_ok = false;
    dispatch_test_slow_buffer = .{0} ** dispatch_test_slow_buffer.len;
    dispatch_test_fast_buffer = .{0} ** dispatch_test_fast_buffer.len;
    const before = runtimeWorkerSummary();

    const slow_index = register(.{
        .name = "dispatch-test-slow",
        .controller = "dispatch-test-controller-slow",
        .bus = .ram,
        .sector_size = 512,
        .sector_count = 1,
        .queue_depth = 1,
        .ctx = null,
        .read_fn = dispatchTestSlowRead,
    }) orelse return dispatchSelfTestResult(false, before, runtimeWorkerSummary());
    dispatch_test_slow_index = slow_index;
    const fast_index = register(.{
        .name = "dispatch-test-fast",
        .controller = "dispatch-test-controller-fast",
        .bus = .ram,
        .sector_size = 512,
        .sector_count = 1,
        .queue_depth = 1,
        .ctx = null,
        .read_fn = dispatchTestFastRead,
    }) orelse {
        _ = unregister(slow_index);
        return dispatchSelfTestResult(false, before, runtimeWorkerSummary());
    };
    dispatch_test_fast_index = fast_index;

    var ok = true;
    var slow_started = false;
    var fast_started = false;
    var fast_observed = false;
    if (sched_task.createKernelThreadWithRole("blk-test-slow", dispatchTestSlowRequester, .batch) == null) {
        ok = false;
    } else {
        slow_started = true;
    }
    if (slow_started and dispatch_test_slow_entered.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled) {
        ok = false;
    } else if (slow_started and sched_task.createKernelThreadWithRole("blk-test-fast", dispatchTestFastRequester, .batch) == null) {
        ok = false;
    } else if (slow_started) {
        fast_started = true;
    }
    if (fast_started and dispatch_test_fast_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) == .signaled) {
        fast_observed = true;
    } else if (fast_started) {
        ok = false;
    }

    dispatch_test_slow_release.signal();
    if (slow_started and dispatch_test_slow_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled) {
        ok = false;
    }
    if (fast_started and !fast_observed and
        dispatch_test_fast_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled)
    {
        ok = false;
    }
    const after = runtimeWorkerSummary();
    ok = dispatch_test_slow_ok and
        dispatch_test_fast_ok and
        after.controller_count >= before.controller_count + 2 and
        after.worker_count >= before.worker_count + 2 and
        after.worker_parallel_active_max >= 2 and
        after.direct_requests >= before.direct_requests + 2 and
        after.bounce_allocations == before.bounce_allocations and
        after.bounce_copy_bytes == before.bounce_copy_bytes and ok;

    const fast_unregistered = unregister(fast_index);
    const slow_unregistered = unregister(slow_index);
    ok = fast_unregistered and slow_unregistered and ok;
    const dispatch_ok = dispatchSelfTestResult(ok, before, after);
    const async_ok = asyncDispatchSelfTest();
    return dispatch_ok and async_ok;
}

fn dispatchTestSlowRead(_: ?*anyopaque, _: u64, _: u16, out: []u8) bool {
    dispatch_test_slow_entered.signal();
    if (dispatch_test_slow_release.waitResult(sync.WAIT_FOREVER) != .signaled) return false;
    @memset(out, 0x53);
    return true;
}

fn dispatchTestFastRead(_: ?*anyopaque, _: u64, _: u16, out: []u8) bool {
    @memset(out, 0x46);
    return true;
}

fn dispatchTestSlowRequester() callconv(.c) void {
    dispatch_test_slow_ok = readDirect(dispatch_test_slow_index, 0, 1, dispatch_test_slow_buffer[0..]);
    dispatch_test_slow_done.signal();
    scheduler.exitCurrent();
}

fn dispatchTestFastRequester() callconv(.c) void {
    dispatch_test_fast_ok = readDirect(dispatch_test_fast_index, 0, 1, dispatch_test_fast_buffer[0..]);
    dispatch_test_fast_done.signal();
    scheduler.exitCurrent();
}

fn dispatchSelfTestResult(ok: bool, before: RuntimeSummary, after: RuntimeSummary) bool {
    k.puts("BLOCKDISPATCHCHECK ");
    k.puts(if (ok) "OK" else "FAIL");
    k.puts(" controllers=");
    k.putDec(after.controller_count);
    k.puts(" workers=");
    k.putDec(after.worker_count);
    k.puts(" parallelMax=");
    k.putDec(after.worker_parallel_active_max);
    k.puts(" directDelta=");
    k.putDec(after.direct_requests -| before.direct_requests);
    k.puts(" bounceAllocDelta=");
    k.putDec(after.bounce_allocations -| before.bounce_allocations);
    k.puts(" bounceCopyDelta=");
    k.putDec(after.bounce_copy_bytes -| before.bounce_copy_bytes);
    k.puts("\r\n");
    return ok;
}

const AsyncTestState = struct {
    submissions: u32 = 0,
    cancels: u32 = 0,
    timeout_cancels: u32 = 0,
    reset_cancels: u32 = 0,
    resets: u32 = 0,
    requests: [8]AsyncRequest = undefined,
};

var async_test_state: AsyncTestState = .{};
var async_test_submitted = sync.EventV2.initMode(false, .auto_reset);
var async_test_first_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_second_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_reset_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_timeout_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_flush_first_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_flush_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_flush_last_done = sync.EventV2.initMode(false, .auto_reset);
var async_test_index: usize = 0;
var async_test_first_ok = false;
var async_test_second_ok = false;
var async_test_reset_ok = true;
var async_test_timeout_ok = true;
var async_test_flush_first_ok = false;
var async_test_flush_ok = false;
var async_test_flush_last_ok = false;
var async_test_first_buffer: [512]u8 = .{0} ** 512;
var async_test_second_buffer: [512]u8 = .{0} ** 512;
var async_test_reset_buffer: [512]u8 = .{0} ** 512;
var async_test_timeout_buffer: [512]u8 = .{0} ** 512;
var async_test_flush_first_buffer: [512]u8 = .{0} ** 512;
var async_test_flush_last_buffer: [512]u8 = .{0} ** 512;

fn asyncDispatchSelfTest() bool {
    async_test_state = .{};
    async_test_submitted = sync.EventV2.initMode(false, .auto_reset);
    async_test_first_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_second_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_reset_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_timeout_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_flush_first_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_flush_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_flush_last_done = sync.EventV2.initMode(false, .auto_reset);
    async_test_first_ok = false;
    async_test_second_ok = false;
    async_test_reset_ok = true;
    async_test_timeout_ok = true;
    async_test_flush_first_ok = false;
    async_test_flush_ok = false;
    async_test_flush_last_ok = false;
    async_test_first_buffer = .{0} ** async_test_first_buffer.len;
    async_test_second_buffer = .{0} ** async_test_second_buffer.len;
    async_test_reset_buffer = .{0} ** async_test_reset_buffer.len;
    async_test_timeout_buffer = .{0} ** async_test_timeout_buffer.len;
    async_test_flush_first_buffer = .{0} ** async_test_flush_first_buffer.len;
    async_test_flush_last_buffer = .{0} ** async_test_flush_last_buffer.len;
    const before = runtimeWorkerSummary();

    const index = register(.{
        .name = "dispatch-test-async",
        .controller = "dispatch-test-controller-async",
        .bus = .ram,
        .sector_size = 512,
        .sector_count = 8,
        .queue_depth = 2,
        .timeout_ticks = 50,
        .ctx = &async_test_state,
        .read_fn = asyncTestSyncRead,
        .async_submit_fn = asyncTestSubmit,
        .async_cancel_fn = asyncTestCancel,
        .async_reset_fn = asyncTestReset,
    }) orelse return asyncDispatchSelfTestResult(false, before, runtimeWorkerSummary());
    async_test_index = index;

    var ok = true;
    if (sched_task.createKernelThreadWithRole("blk-async-a", asyncTestFirstRequester, .batch) == null or
        sched_task.createKernelThreadWithRole("blk-async-b", asyncTestSecondRequester, .batch) == null)
    {
        ok = false;
    }
    if (ok and !asyncTestWaitForSubmissions(2)) ok = false;
    if (ok) {
        if (get(index)) |device| {
            if (device.active_executions != 2) ok = false;
        } else {
            ok = false;
        }
    }
    if (ok) {
        const second = asyncTestFindRequest(.read, 1) orelse return asyncDispatchSelfTestResult(false, before, runtimeWorkerSummary());
        const first = asyncTestFindRequest(.read, 0) orelse return asyncDispatchSelfTestResult(false, before, runtimeWorkerSummary());
        if (second.buffer) |buffer| @memset(buffer[0..second.buffer_len], 0xB2);
        if (first.buffer) |buffer| @memset(buffer[0..first.buffer_len], 0xA1);
        second.complete(second.handle, ASYNC_RESULT_OK, @intCast(second.buffer_len));
        second.complete(second.handle, ASYNC_RESULT_OK, @intCast(second.buffer_len));
        first.complete(first.handle, ASYNC_RESULT_OK, @intCast(first.buffer_len));
    }
    if (async_test_first_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled or
        async_test_second_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled)
    {
        ok = false;
    }
    ok = async_test_first_ok and async_test_second_ok and
        async_test_first_buffer[0] == 0xA1 and async_test_second_buffer[0] == 0xB2 and ok;

    const reset_task = sched_task.createKernelThreadWithRole("blk-async-reset", asyncTestResetRequester, .batch);
    if (reset_task == null) {
        ok = false;
    }
    if (ok and !asyncTestWaitForSubmissions(3)) ok = false;
    var late_handle: u64 = 0;
    if (ok) {
        late_handle = (asyncTestFindRequest(.read, 2) orelse return asyncDispatchSelfTestResult(false, before, runtimeWorkerSummary())).handle;
        const kill_deferrals_before = sched_task.killHeldLockDeferrals();
        if (sched_task.kill(reset_task.?.id) or sched_task.killHeldLockDeferrals() <= kill_deferrals_before) ok = false;
        // Unload admission must remain transactional while either a caller pin
        // or a hardware-owned request is live.
        if (unregister(index)) ok = false;
        if (!reset(index, CANCEL_REASON_RESET)) ok = false;
    }
    if (async_test_reset_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled) ok = false;
    if (late_handle != 0) asyncBackendComplete(late_handle, ASYNC_RESULT_OK, 512);

    if (sched_task.createKernelThreadWithRole("blk-async-timeout", asyncTestTimeoutRequester, .batch) == null) {
        ok = false;
    }
    if (ok and !asyncTestWaitForSubmissions(4)) ok = false;
    if (async_test_timeout_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled) ok = false;
    ok = !async_test_timeout_ok and async_test_state.timeout_cancels == 1 and ok;

    // Queue read -> flush -> read while depth two is available. The flush may
    // not be submitted beside the first read, and the later read may not pass
    // it. This covers the actual async path rather than only the pure policy.
    if (sched_task.createKernelThreadWithRole("blk-async-before-flush", asyncTestFlushFirstRequester, .batch) == null) {
        ok = false;
    }
    if (ok and !asyncTestWaitForSubmissions(5)) ok = false;
    if (sched_task.createKernelThreadWithRole("blk-async-flush", asyncTestFlushRequester, .batch) == null) {
        ok = false;
    }
    if (ok and (async_test_submitted.waitResult(5) != .timeout or queueUsed(index) != 2)) ok = false;
    if (sched_task.createKernelThreadWithRole("blk-async-after-flush", asyncTestFlushLastRequester, .batch) == null) {
        ok = false;
    }
    if (ok and (async_test_submitted.waitResult(5) != .timeout or queueUsed(index) != 3)) ok = false;
    if (ok) {
        const first = async_test_state.requests[4];
        if (first.kind != .read or first.lba != 4) {
            ok = false;
        } else {
            if (first.buffer) |buffer| @memset(buffer[0..first.buffer_len], 0xC4);
            first.complete(first.handle, ASYNC_RESULT_OK, @intCast(first.buffer_len));
        }
    }
    if (ok and !asyncTestWaitForSubmissions(6)) ok = false;
    if (ok) {
        const flush_request = async_test_state.requests[5];
        if (flush_request.kind != .flush or async_test_state.submissions != 6) {
            ok = false;
        } else {
            flush_request.complete(flush_request.handle, ASYNC_RESULT_OK, 0);
        }
    }
    if (ok and !asyncTestWaitForSubmissions(7)) ok = false;
    if (ok) {
        const last = async_test_state.requests[6];
        if (last.kind != .read or last.lba != 5) {
            ok = false;
        } else {
            if (last.buffer) |buffer| @memset(buffer[0..last.buffer_len], 0xD5);
            last.complete(last.handle, ASYNC_RESULT_OK, @intCast(last.buffer_len));
        }
    }
    if (async_test_flush_first_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled or
        async_test_flush_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled or
        async_test_flush_last_done.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled)
    {
        ok = false;
    }
    ok = async_test_flush_first_ok and async_test_flush_ok and async_test_flush_last_ok and
        async_test_flush_first_buffer[0] == 0xC4 and async_test_flush_last_buffer[0] == 0xD5 and ok;

    const after = runtimeWorkerSummary();
    ok = !async_test_reset_ok and
        async_test_state.cancels == 2 and
        async_test_state.reset_cancels == 1 and
        async_test_state.resets == 1 and
        after.in_flight_high_water >= 2 and
        after.duplicate_completions > before.duplicate_completions and
        after.late_completions > before.late_completions and ok;
    ok = unregister(index) and ok;
    return asyncDispatchSelfTestResult(ok, before, after);
}

fn asyncTestWaitForSubmissions(expected: u32) bool {
    while (async_test_state.submissions < expected) {
        if (async_test_submitted.waitResult(2 * @as(u64, timer.DEFAULT_HZ)) != .signaled) return false;
    }
    return async_test_state.submissions == expected;
}

fn asyncTestFindRequest(kind: RequestKind, lba: u64) ?AsyncRequest {
    var index: usize = 0;
    while (index < async_test_state.submissions) : (index += 1) {
        const request = async_test_state.requests[index];
        if (request.kind == kind and request.lba == lba) return request;
    }
    return null;
}

fn asyncTestSyncRead(_: ?*anyopaque, _: u64, _: u16, _: []u8) bool {
    return false;
}

fn asyncTestSubmit(ctx: ?*anyopaque, request: *const AsyncRequest) i32 {
    const state: *AsyncTestState = @ptrCast(@alignCast(ctx orelse return -1));
    if (state.submissions >= state.requests.len) return -1;
    state.requests[state.submissions] = request.*;
    state.submissions += 1;
    async_test_submitted.signal();
    return 0;
}

fn asyncTestCancel(ctx: ?*anyopaque, handle: u64, reason: u32) i32 {
    const state: *AsyncTestState = @ptrCast(@alignCast(ctx orelse return -1));
    state.cancels += 1;
    if (reason == CANCEL_REASON_TIMEOUT) {
        state.timeout_cancels += 1;
        var index: usize = 0;
        while (index < state.submissions) : (index += 1) {
            const request = state.requests[index];
            if (request.handle != handle) continue;
            request.complete(handle, ASYNC_RESULT_CANCELLED, 0);
            return 0;
        }
        return -1;
    }
    if (reason == CANCEL_REASON_RESET) state.reset_cancels += 1;
    return 0;
}

fn asyncTestReset(ctx: ?*anyopaque, _: u32) i32 {
    const state: *AsyncTestState = @ptrCast(@alignCast(ctx orelse return -1));
    state.resets += 1;
    return 0;
}

fn asyncTestFirstRequester() callconv(.c) void {
    async_test_first_ok = readDirect(async_test_index, 0, 1, async_test_first_buffer[0..]);
    async_test_first_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestSecondRequester() callconv(.c) void {
    async_test_second_ok = readDirect(async_test_index, 1, 1, async_test_second_buffer[0..]);
    async_test_second_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestResetRequester() callconv(.c) void {
    async_test_reset_ok = readDirect(async_test_index, 2, 1, async_test_reset_buffer[0..]);
    async_test_reset_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestTimeoutRequester() callconv(.c) void {
    async_test_timeout_ok = readDirect(async_test_index, 3, 1, async_test_timeout_buffer[0..]);
    async_test_timeout_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestFlushFirstRequester() callconv(.c) void {
    async_test_flush_first_ok = readDirect(async_test_index, 4, 1, async_test_flush_first_buffer[0..]);
    async_test_flush_first_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestFlushRequester() callconv(.c) void {
    async_test_flush_ok = flush(async_test_index);
    async_test_flush_done.signal();
    scheduler.exitCurrent();
}

fn asyncTestFlushLastRequester() callconv(.c) void {
    async_test_flush_last_ok = readDirect(async_test_index, 5, 1, async_test_flush_last_buffer[0..]);
    async_test_flush_last_done.signal();
    scheduler.exitCurrent();
}

fn asyncDispatchSelfTestResult(ok: bool, before: RuntimeSummary, after: RuntimeSummary) bool {
    k.puts("BLOCKASYNCCHECK ");
    k.puts(if (ok) "OK" else "FAIL");
    k.puts(" inflightMax=");
    k.putDec(after.in_flight_high_water);
    k.puts(" submits=");
    k.putDec(after.async_submissions -| before.async_submissions);
    k.puts(" completions=");
    k.putDec(after.async_completions -| before.async_completions);
    k.puts(" duplicates=");
    k.putDec(after.duplicate_completions -| before.duplicate_completions);
    k.puts(" late=");
    k.putDec(after.late_completions -| before.late_completions);
    k.puts(" resets=");
    k.putDec(after.async_resets -| before.async_resets);
    k.puts(" cancels=");
    k.putDec(after.async_cancel_requests -| before.async_cancel_requests);
    k.puts("\r\n");
    return ok;
}

fn busName(bus: Bus) []const u8 {
    return switch (bus) {
        .unknown => "unknown",
        .ata => "ata",
        .ahci => "ahci",
        .nvme => "nvme",
        .usb => "usb",
        .ram => "ram",
        .virtio => "virtio",
    };
}

fn stateName(state: State) []const u8 {
    return switch (state) {
        .registered => "registered",
        .active => "active",
        .busy => "busy",
        .recovering => "recovering",
        .failed => "failed",
    };
}

fn errorName(err: Error) []const u8 {
    return switch (err) {
        .none => "none",
        .busy => "busy",
        .invalid_request => "invalid-request",
        .request_too_large => "request-too-large",
        .out_of_range => "out-of-range",
        .buffer_too_small => "buffer-too-small",
        .no_writer => "no-writer",
        .timeout => "timeout",
        .backend_read => "backend-read",
        .backend_write => "backend-write",
        .backend_flush => "backend-flush",
        .cancelled => "cancelled",
        .reset => "reset",
        .shutdown => "shutdown",
    };
}

fn sourceName(source: Source) []const u8 {
    return switch (source) {
        .builtin => "built-in",
        .preload => "preload",
        .disk => "disk",
    };
}

fn kindName(kind: RequestKind) []const u8 {
    return switch (kind) {
        .none => "none",
        .read => "read",
        .write => "write",
        .flush => "flush",
    };
}

fn strEqIgnoreCase(a: []const u8, b: []const u8) bool {
    if (a.len != b.len) return false;
    var i: usize = 0;
    while (i < a.len) : (i += 1) {
        const ca = if (a[i] >= 'A' and a[i] <= 'Z') a[i] + 32 else a[i];
        const cb = if (b[i] >= 'A' and b[i] <= 'Z') b[i] + 32 else b[i];
        if (ca != cb) return false;
    }
    return true;
}

test "preload v2 storage uses synchronous boot fallback before async runtime" {
    try std.testing.expect(!useAsyncSubmission(.boot_inline, true));
    try std.testing.expect(useAsyncSubmission(.runtime_worker, true));
    try std.testing.expect(!useAsyncSubmission(.runtime_worker, false));
}
