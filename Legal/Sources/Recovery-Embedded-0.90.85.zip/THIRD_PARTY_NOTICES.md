﻿# Third-Party Notices

Original R4OS material is Apache-2.0. Imported materials retain their original
licenses. `Provenance/inputs.lock.json` records source repositories, commits,
binary versions, manifests and hashes. `Legal/Sources/` contains exact source
archives for the pinned build inputs; each archive preserves its own notices
and third-party license texts. Extracted owner notices are in `Legal/Notices/`.

`Runtime/R4OS/DRIVERS/RTL8168.R4D` contains firmware/register tables extracted
from GPL-2.0-only Realtek vendor material. This binary retains that license;
it is not relicensed under Apache-2.0. See
`Legal/Notices/Drivers-RTL8168/LICENSE-GPL-2.0-only.txt` and the corresponding
complete source archive `Legal/Sources/Drivers-RTL8168.zip`. The pinned SDK,
contract and build sources used with it are supplied in the same source set.

The original Libraries source archive includes its third-party image/font
sources and their licenses; Recovery currently imports only R4STD.R4L from
that owner. The pinned SDK includes NTFS test fixtures, with their recorded
origin and notices. The Distribution archive includes its own bootloader,
font, certificate and other distribution notices. No optional image/font,
audio, browser or desktop runtime module is imported by implication.

The kernel implements the public Limine protocol. Actual bootloader files and
the Recovery background asset will be imported explicitly with their boot/UI
implementation steps and recorded in the input inventory.

## Shared NTFS formatter metadata

The 16 production metadata templates under
`Platform/SDK/r4os/storage_tools/ntfs_metadata` are byte-identical copies of
the existing Windows-generated NTFS fixture data. Their source paths and
hashes are recorded in `provenance.json`; the pinned SDK notices and original
fixture generation records remain included. The shared formatter is R4OS
source explicitly imported from Distribution, not Microsoft formatter code.

## R4PART console application

R4PART is imported from `R4OSDev/r4os-app-r4part` with the exact committed
source archive in `Legal/Sources/Apps-R4Part.zip` and original notices in
`Legal/Notices/Apps-R4Part`. Its common formatter includes the same documented
NTFS metadata templates described above. The owner build, source revision,
SDK revision and binary hash are recorded in `Provenance/owner-update-0.76.10.json`.

## Canonical platform source adoption (0.90.84)

The complete Contract93 and SDK210 owner archives are preserved separately
as `Legal/Sources/Contract-0.90.84.zip` and `SDK-0.90.84.zip`; historical
archives and notices remain intact. Current extracted notices are under
`Legal/Notices/Contract-0.90.84` and `Legal/Notices/SDK-0.90.84`.
The latter also retains the complete Unicode License v3 and R4STD license
for the canonical SDK's static grapheme snapshot, and the BSD-2-Clause
license for its Limine BIOS adapter. The SDK archive retains the original
MIT notice for the SHA256 compression leaf and all original source
provenance. This source adoption does not relicense imported material.
