﻿# R4OS Recovery

R4OS Recovery is the independent recovery environment developed in R4OS roadmap
0.76.X. It boots through Limine with its own lightweight kernel and a
complete RAM-resident console runtime.

Recovery0.1.70 / its own Zig Kernel0.1.69 and Menu0.1.28 implement the
canonical Query2/Start2/DriverInit2/ProtocolInit2 interfaces. The Recovery
owner builds all39 embedded modules:38 explicit source derivatives under
`RecoveryTools/Embedded/`, plus canonical R4STD0.2.9 from the pinned
Libraries0.64.58 snapshot. Their original source archives remain available.
Contract0.64.93, snapshot SDK0.64.210 and Libraries0.64.58 retain their exact
canonical source bytes, except for the three documented `.gitattributes`
host policies. SDK0.64.212 controls the shared Linux/Windows build.

The IPv4 family service path uses the current DNS/TCP/UDP owner sources and
the canonical DNS address codec. The kernel supplies only resident backend
capabilities, retained TCP terminal states until explicit close, and UDP
datagram truncation with original length and zero-byte packet identity.
Typed listeners, IPv6 transport and dual-stack are not advertised by this
Recovery backend. Optional preferred dispatcher placement is requested only
when its actual provider functions exist. Direct App2 network boundary probes
and the real GitHub HTTPS/redirect/digest witness pass; the complete download
and deployment matrices retain their separate completion status.

The current Linux/KVM qualification and exact source/artifact identities are
recorded in Provenance and DOCUMENTATION.de.txt. Older candidate results keep
their original pair identities. The 0.90.85 Linux/KVM4 qualification passes
RAM6/storage7/input8/menu6/package2/download8/install9/system-update3/recovery-
update6 and the original host-fault cases. Download8 joins the exact main
component and seven original cut/FAT cases; the original90s startup failure
remains failed evidence. The original RAM UEFI pre-kernel Limine-open failure
remains unresolved and tracked in Problems/coldboot audit87; the same-image
fresh-variable diagnostic and one complete original6 countercheck pass.
Install9 joins5 original operations and4 VerifyInstalled result boots after
the preserved early-keyboard failure; actual second Terminal prompt admission,
normal typedPOWEROFF and whole base-image oracles remain. System update
uses the same visual host admission; Slim need not auto-start SSH.
Recovery update retains all original6 native and6 injected host-fault
cases with a private512MiB fault fixture and actual-GPT bounded host
state/write-plan adapters; original256MiB pre-guest ImageFull is retained.
Package READY reached69.277s; its ZIP-size-bounded host allowance preserves
the original detach/hash/RAM/target oracles and product acknowledgement.
One UEFI menu case lacks retained live-FD observation after an interruption;
its original functional result remains intact. One independently verified normal STANDARD uses the
unchanged five scored normal artifacts; it is not a Recovery performance claim.
Claim/original import/fullGET/independent server scoring remain pending under
the explicit local closure exception. This source work does not publish
a binary release or qualify execution on Windows or physical hardware.
The old technical platform provider remains until the controlled0.90.89 cutover.

The current baseline contains pinned kernel, platform contract and SDK sources,
39 source-built console, service, driver, protocol and library modules, and
their original source archives and license notices. Since 0.76.2 the separate
Recovery kernel boots under BIOS and UEFI without a SYSTEM partition. The
complete 64-MB FAT32 runtime is loaded by Limine, checked against its kernel's
recorded runtime hash, and mounted as writable RAM drive C: in 0.76.3. Since 0.76.6,
RECOVERY.R4X hosts the menu and the standard Terminal inside the supplied
background's monitor. Since 0.76.7, DHCP and the included SSH/FTP services start
from RAM; independent remote shells and transfers can repair offline volumes.
Both services use the agreed `r4os` / `rosebud` login.

Run `Build.bat` on Windows or `./Build.sh` on Linux with PowerShell 7 to verify
the local inventory. The shared `Build.ps1` checks file hashes, actual binary
imports, protocol dependencies and original manifests. It does not import
from the normal workspace or fetch dependencies. Results are written to
`Artifacts/Verification/inventory.json`.

Add `-Mode Kernel` to build `Artifacts/Kernel/bin/recovery.elf` using the
recorded Zig version and the paired `Artifacts/Runtime/runtime.img`.
`-Mode Embedded` builds all39 modules from their locked sources using the
shared SDK profiles. It verifies the admitted runtime artifacts and refuses
an unrecorded replacement. `-Mode Runtime` builds the paired volume and the
Recovery-owned console tools.
`-Mode RuntimeTest` uses a separate `Artifacts/RuntimeApi2/runtime.img` and
real App2/DriverInit2/ProtocolInit2 diagnostic fixtures. It checks late module
and media access after actual USB removal,32 imports, metadata/clock/RDRAND,
process lifetime, DMA/unload, normal console commands, RAM writes and the
original invalid boot payloads. Production runtime images exclude these probes. After the normal
kernel build, `pwsh -File Tools/Test-Boot.ps1 -Action terminal` exercises the
production menu's Terminal with keyboard input and regular shutdown after
removing the boot medium.
`-Mode NetworkTest` checks SSH/SFTP/SCP, active/passive FTP, offline file
repair, isolated console output, and an offline boot with damaged SYSTEM.
It needs host OpenSSH clients.
Add `-Mode BootTest` for the bounded BIOS/UEFI SMP4
foundation check, or `-Mode BootTest -BootProbe reboot` to verify reset.
Diagnostic kernels and logs remain in `Artifacts/BootProbe/`. The Linux UEFI
check uses the Debian `ovmf` package; Windows uses matching firmware from QEMU.

An explicit initial import uses `Tools/Import.ps1` and the source revisions in
`Provenance/import-plan.json`. Later explicit owner transfers record the
base commit, source patch and content hashes under Provenance and Legal.
Source and configuration changes are recorded
separately with `Tools/Record-Inputs.ps1 -Reason 'description'`; this is never
an automatic build action. See [DOCUMENTATION.de.txt](DOCUMENTATION.de.txt)
and [the technical contracts](RecoveryTools/Contracts.de.txt) for details.

## Recovery tools

- Install R4OS from a stored release ZIP or a release downloaded from GitHub.
- GitHub downloads show transferred and total size, percentage, and speed;
  interrupted transfers resume up to three times and report the final cause.
- Replace a selected R4OS system installation and update Recovery independently.
- Manage partitions through the reusable R4PART console application.
- Run the existing terminal and provide SSH and FTP access for offline repair.
- Use keyboard input and display menus and console programs inside the recovery
  background's monitor area.

Update Recovery preserves a verified PREVIOUS package before replacing CURRENT.
Only a confirmation matching the installation, manifest and actually booted
kernel/runtime can promote CURRENT to PREVIOUS. The running session stays in
RAM. A failed update can be recovered through the fixed Previous entry in
Limine; shared filesystem or bootloader damage still needs an external USB.
The original ZIP cache and existing Limine configuration remain intact.

The Recovery-owned SYSUPD core and its pinned SDK accept only journal v5.
V2–v4 are rejected; v5 identities, checksums, restart-batch continuation and
rollback, including new files without old contents, remain supported. The
separate R4CACHE1 and Recovery package journals keep their existing formats.

The recovery kernel reuses selected R4OS kernel components. Compatible
drivers, protocols, services, console applications, and libraries are
imported as a pinned, jointly verified set. Recovery has its own release cycle;
normal R4OS packages include an explicitly selected complete Recovery release.

Recovery 0.1.68 / its own Kernel 0.1.65 keeps the RX worker running when a
next-hop ARP entry expires. The worker requests resolution without waiting;
TCP retains the unsent ACK, FIN or retransmit until a later activation.
Requests are paced per adapter. This prevents queued TCP traffic from hiding
an already received ARP reply behind recursive resolution waits. A routed
64-MB SMP4 transfer reproduces the old collapse after the 30-second ARP TTL;
the corrected pair transfers every byte with the expected SHA-256 across
two router-cache expirations. The imported runtime modules and Menu 0.1.26
remain byte-identical. This guest result does not replace an OssiPC retest.

The 0.1.66 source profile (roadmap 0.86.81) adopts only the needed current
SDK font, Unicode and generation-bound network request semantics. Missing
callbacks return unavailable; glyph rows, font generations and raw IPC do not
substitute for those callbacks. The three obsolete diagnostic prefix providers
are disabled at their existing optional slots 27/29/30; full V2 diagnostics
remain. The frozen Contract 0.64.11 and R4DEV v8/344-byte table keep their
identities and layout. This is an independent profile transfer, not an import
of the normal R4DEV v35/728-byte table or the full normal SDK.
The original 39 runtime modules, their archives and transactional update,
rollback, boot confirmation and kernel/runtime pairing remain pinned. Exact
owner commits, semantic patches and hashes are in
`Provenance/owner-update-0.86.81.json`.

`./Release.sh Prepare` (Windows: `Release.bat Prepare`) creates the independent
ZIP, input/owner provenance and SHA256SUMS from the clean, pushed Recovery
source. After qualification, `Publish -Prepared` uploads those exact assets
through the shared workspace GitHub transport without regenerating the ZIP,
source manifest, checksums or custom release notes. It verifies the clean
source commit, input lock, owner receipts and current kernel/runtime/legal
file identities against the prepared source manifest and checksums;
it does not build normal R4OS. The production kernel's named pair section must
match the exact runtime and both versions. Use `Prepare -Technical` only for
explicit local acceptance candidates; `Publish` refuses technical mode.
`SelfTest` checks the local producer/pair contract without a network upload.

## Repository layout

The pinned inputs and their owners are separated explicitly:

    Kernel/             Recovery kernel sources
    Platform/Contract/  Pinned platform API and ABI contract
    Platform/SDK/       Pinned SDK sources
    Platform/Libraries/ Pinned canonical library sources
    Platform/Distribution/  Explicitly frozen ImageCreator sources
    RecoveryTools/      Recovery menu, embedded source derivatives and workflows
    Runtime/            Configuration, imported modules, and recovery media
    Provenance/         Import versions, source commits, hashes, and manifests
    Legal/              Original source archives, manifests and notices
    Tools/              Build, import, and release tooling

Imported runtime binaries are versioned together with their provenance and
license notices. Generated build and release outputs remain untracked. Shared
host orchestration uses PowerShell 7 with thin Windows and Linux launchers.

## Workspace integration

The canonical checkout is `Repositories/Recovery` within the
[R4OS project workspace](https://github.com/R4OSDev/r4os-project). From the
workspace root, use `Tools\Github.bat -Pull -Recovery` on Windows or
`./Tools/Github.sh -Pull -Recovery` on Linux. The repository uses `main` and the
public remote `https://github.com/R4OSDev/r4os-recovery.git`.

## License

Original R4OS material is licensed under Apache License 2.0. See
[LICENSE](LICENSE), [NOTICE](NOTICE), and
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

Seit 0.76.4 stehen das physische Medieninventar, die echte Limine-Bootquelle
und stabile C:/R:/weitere Mounts bereit. `-Mode StorageTest` prueft die
USB-/AHCI-/NVMe- und Fehlerfaelle mit SMP4. Installation und beide Updatewege
sind implementiert. Details und Grenzen stehen in
[DOCUMENTATION.de.txt](DOCUMENTATION.de.txt).

## Keyboard input

`./Build.sh -Mode InputTest` (Windows: `Build.bat -Mode InputTest`) exercises
PS/2 and USB keyboards through BIOS/UEFI Recovery guests with four CPUs.
USB-only cases disable the emulated PS/2 controller. The shared input path
supports R4OS layouts, navigation and the existing Terminal; Recovery does
not bind a mouse. Results live under `Artifacts/BootProbe/input/`.

Since Recovery 0.1.64, every detected xHCI function owns independent state,
DMA/rings, IRQ routing and worker identity. USB device handles include the
controller ID and runtime generation. PCI diagnosis reports that exact
function; detached media cannot address a replacement through an old handle.
The frozen Zig adaptation and source hashes are recorded in
`Provenance/owner-update-0.86.27.json`; its input lock remains explicit.

For the affected three-controller case, build with `./Build.sh -Mode Kernel
-BootProbe input`, then run `pwsh -File Tools/Test-Input.ps1 -Controllers 3
-Boot Usb -Keyboard Usb -Firmware Both`. This existing input acceptance also
admits the shared mouse backend inside the probe only. Keyboard, mouse and
boot source use separate controllers; an additional 8-MB raw medium exercises
256-KB reads/writes and detach/replug with stale-identity rejection. Completed
fixture images are removed. The production Recovery UI remains keyboard operated.

Recovery 0.1.65 / Recovery Kernel 0.1.63 carries the retained USB optimizations
from normal Kernel 0.1.381. Each controller has nine resident completion wait slots; exact
mailbox matching grants completion, with a bounded one-tick progress fallback
under the original deadline. HID subscribes by runtime generation and endpoint,
wakes its resident worker after mailbox publication and keeps a 100-ms idle
fallback. Completed reports are copied before the next subscribed transfer is
reserved and armed; detached keyboard state is retained until release decoding.
Endpoint DMA groups are allocated on demand, with local rollback only before
publication and acknowledgement-based retention afterwards. Successful shutdown
notifies the existing class topology hook after the last controller guard.
Same-runtime persistence and the original bulk copy/64-KB contracts remain.
The semantic delta is recorded in `Provenance/owner-update-0.86.32.json`.

The same three-controller input acceptance additionally checks 68 owned DMA
pages, bounded idle worker activity, real controller INTE suppression with
direct backing-file I/O and completion fallback, and held-Shift retirement
before a replacement keyboard receives key-up. BIOS and UEFI remain two
short affected cases; other installation/network tests need no repetition.

## Recovery console host

`RecoveryTools/Menu` owns RECOVERY.R4X and builds against the pinned SDK and
Contract. The39 embedded source builds and the separate Recovery application are
verified together before creating the runtime image. Its manifest and source
participate in input verification, and the build checks its real imports.

The six English menu entries use Up/Down and Enter. Terminal starts the
Generation2 TERMINAL.R4X in a separate console session; EXIT restores the menu.
Image scaling, text, cursor, scrolling and clear are confined to the source
image's monitor. The shell uses existing R4DRAW and console-host APIs without
a desktop. The footer shows the actual SSH address or network waiting state.
The first three entries select a fixed cached ZIP or their GitHub channel,
then a live disk or an identified SYSTEM/RECOVERY partition. Review defaults
to Back and revalidates the target before dispatch. Since 0.76.15, local
packages are checked through the frozen R4ZIP protocol and prepared in pinned
physical RAM. Install R4OS and Update R4OS execute their validated write plans;
Update Recovery rotates confirmed CURRENT to PREVIOUS before replacement.
Readable OS markers add comma-separated names; no
marker leaves the extra display empty. Details and current limits are in
[DOCUMENTATION.de.txt](DOCUMENTATION.de.txt).

`-Mode UITest` exercises BIOS at 640x480, 800x600, 1024x768 and 1920x1080 plus UEFI at
1024x768, with four CPUs and a USB keyboard. Its `/UISMOKE` diagnostic session
uses the existing shell stdout mirror and a second standard Terminal to
check console isolation. QMP screendumps compare every pixel outside the
monitor, and verify visible selection, dialogs, progress, clear, scrolling,
Terminal return and reset. The disk fixtures cover an existing installation,
a blank disk and combined OS markers. `Tools/Test-UI.ps1 -BootMedium LOCAL
-Firmware Bios -Resolution 1024x768x32` checks local-source USB exclusion and
own-disk eligibility. Artifacts stay under `Artifacts/BootProbe/ui/`.

`Tools/Package.ps1` owns the independent Recovery ZIP producer; the frozen
Distribution `Tools/ReleasePackage.ps1` supplies self-contained test fixtures.
The canonical Distribution owns the current production OS package.
`./Build.sh -Mode PackageTest` (Windows: `Build.bat -Mode PackageTest`)
builds the production package kernel and existing UI diagnostic kernel, then
generates real .NET ZIP fixtures, checks
the shared guest decoder and NTFS content import on the host, and runs bounded
SMP4 guest package checks. After those builds,
`pwsh -File Tools/Test-Packages.ps1 -HostOnly` or `-GuestOnly` selects one half.
Physical installation has its separate complete-package acceptance. Public
channel checks additionally verify the actual released assets.

`./Build.sh -Mode DownloadTest` uses the production Recovery kernel and the
same guest web transport. It checks a real GitHub HTTPS/redirect download,
controlled complete and invalid packages, separate fixed caches, available
space, actual power cuts at three durable cache boundaries and representative
FAT32 alias/orphan-LFN states. Only disposable images under Artifacts are
written; an extra installation disk must remain byte-identical. Logs and
hashes live under `Artifacts/BootProbe/downloads/`. `Tools/Test-Downloads.ps1`
can select `-LiveOnly` or `-NoCuts`; `-ReuseFixture` requires matching recorded
input and fixture hashes. The complete production release channels are
checked after publication in the release integration step.

Since 0.76.9, the pinned SDK and ImageCreator share GPT/MBR editing and streamed
FAT32/NTFS formatting. `-Mode StorageToolsTest` exercises those same routines
through real guest claims on a disposable 128-MB NVMe disk, then mounts both
filesystems and checks file access. The existing network runner provides
BIOS/UEFI SMP4 and menu/remote-access coverage in the same sessions.

Since 0.76.10, Manage Partitions starts the frozen R4PART.R4X directly.
The same console application is installed in the normal R4OS Terminal path.
It provides real disk/partition/volume inventory, selection, GPT/MBR creation
and editing, FAT32/NTFS Quick/Full formatting, drive letters and mount state.
Writes require an explicit confirmation naming the target disk/partition.
R4PART imports the console portion of R4DESK as well as physical R4SYS storage.
Neither a desktop nor GUI applications are required.

`-Mode R4PartTest` extends the existing network acceptance with real R4PART
operations on a disposable NVMe, identifier changes and the menu/Terminal
return paths. `pwsh -File Tools/Test-R4Part-Normal.ps1` exercises that identical
binary in an already built normal Full image, then verifies the ordinary
local Terminal in a private QEMU snapshot. Both run with four virtual CPUs.

Since 0.76.18, Install R4OS performs the complete replacement after the
existing source, target and confirmation steps. It validates the original
release ZIP and the agreement between its outer BOOT files, inner image,
SYSTEM catalog and pinned Recovery. Every write plan and the original ZIP
reside in pinned RAM before exclusive access. The common SDK creates fresh
GPT identities, BOOT/SYSTEM/RECOVERY and DATA using the actual target size.
Both Recovery slots and INSTALL/RELEASE.ZIP are installed. Completion requires
flush/readback, new mount identities and a full hash of the stored original.

Build the production kernel with `-Mode Kernel` and its diagnostic UI sibling
with `-Mode Kernel -BootProbe ui`. `Tools/Test-Install.ps1 -SourcePackage PATH`
uses that real installer with a validated complete R4OS package on disposable
SMP4 QEMU media. It covers USB installation, own-device local replacement,
write failure and low RAM, then independently checks and boots successful
results. `-ReuseFixture` requires matching hashes; `-VerifyInstalled` only
rechecks already recorded results and boots them through snapshots.

Since 0.76.19, Update R4OS rebuilds the selected SYSTEM in its existing
partition and updates the matching normal kernel/preload/BOOT files from
the same validated release ZIP. Capacity includes NTFS metadata; a fitting
nonstandard SYSTEM size is retained. All old SYSTEM files and settings are
replaced. DATA, RECOVERY, GPT identities and partition boundaries persist.

BOOT is updated at file level. Its existing limine.conf bytes, foreign files,
names and attributes are retained. Preparation requires canonical R4OS
kernel/preload references in the existing configuration and the supported
Limine BIOS chain. A private FAT plan checks allocation ownership and space
before either write claim. BOOT and SYSTEM have separate exclusive claims;
the table and original BOOT fingerprint are checked again before writing.
Failure after writes is reported as incomplete, with affected claims closed
and unfinished filesystems kept offline. This recovery operation has no
transaction rollback or power-failure guarantee.

`Tools/Test-SystemUpdate.ps1 -SourcePackage PATH -BaseImage PATH` exercises
the menu on disposable USB/NVMe SMP4 guests. The fixture uses a standard old
2048-MB image and creates 768-MB and too-small SYSTEM variants. Independent
checks compare persistent partitions, GPT, custom menu bytes and foreign
BOOT files; a read-only NTFS witness checks the complete replacement tree.
The successfully updated normal system must boot and respond to Terminal.


## Qualified requirements and integration

The package producer's preliminary capacity check uses the existing 5-GB
fresh-install RECOVERY geometry, matching the pinned SDK installation policy
and current Distribution profiles. The old 512-MB producer limit was stale.
Both complete slots, this package's ZIP/PART pair and metadata reserve must
fit. Distribution also checks the actual FAT allocation and the real release
ZIP/PART pair. Updates preserve existing geometry; legacy smaller targets
must independently pass their real free-space checks before any write.

The prepared Recovery/Kernel 0.1.23 and RECOVERY.R4X 0.1.14 retain the
64-MB runtime. ZIP image import uses a 160-KB decoder window and nonzero
64-KB blocks, then releases the image after resolving and verifying SYSTEM.
Fresh FAT plans borrow payloads; update plans retain only touched sectors.
The largest observed total in three SMP4/6-GB workflows is 1,466,601,472
bytes. Adding 512 MB reserve and rounding up gives a new package minimum
of 2 GB OS-usable RAM. Final asset qualification is planned for 0.78.14.
The complete source and write plans must fit in physically reserved RAM
before any target write. New installations use 128 MB BOOT, 16 GB SYSTEM
and 5 GB RECOVERY; DATA uses the remaining space. Standard source images are
22 GB. Recovery also reads the previous 16-GB (10-GB SYSTEM) and 2-GB
(1-GB SYSTEM) source images. Updates retain the target geometry and IDs.

`Artifacts/Qualification/0.76.23/report.json` records actual RAM peaks,
capacity, complete install/update evidence and exact package identities.
`Artifacts/Qualification/0.76.24/report.json` adds combined BIOS/UEFI,
USB/local keyboard UI, remote repair/storage/R4PART, local self-update,
download power cuts and normal boot integration. All automated guests use
four CPUs and run sequentially. SeaBIOS 1.17's high-RAM NVMe boot limitation
is handled by the shared host firmware PCI allocation setting; no kernel
change is needed. Historical single failures remain documented separately.

After publication, `Tools/Test-PublishedRelease.ps1` downloads the entire
actual public Recovery or R4OS asset through the production keyboard menu,
verifies its cached bytes and preserves unrelated partitions. Historical
hardware observations are recorded with their exact release below.


Recovery [0.1.20](https://github.com/R4OSDev/r4os-recovery/releases/tag/v0.1.20)
is published with its source receipt and checksums. The full public asset
passed the production-menu download acceptance; its unpacked contents match
the qualified kernel/runtime/license payloads exactly. Normal Distribution
pins the release ID and complete ZIP SHA256 explicitly.

The Lenovo USB boot with 0.1.19 succeeded, but its package rejected the
reported 6136 MB of usable RAM against the old 7168-MB minimum. Recovery
0.1.20 lowers the package minimum to 5120 MB and reports detected/required
RAM on rejection. The source package supplies this requirement, so an old
R4OS ZIP must be replaced with one containing the corrected Recovery.
`Artifacts/Qualification/0.76.26/ram/report.json` records eight passing SMP4
cases: installation, SYSTEM update, Recovery self-update and their result
boots at 6 GB, plus a 4-GB rejection that leaves the target byte-identical.
The largest observed RAM peak was 4,091,301,888 bytes during self-update.
The user confirmed the corrected Lenovo USB boot and local installation,
then also reported that the installed R4OS booted locally and was running.
The unchanged qualified Full ZIP was published with Slim as
[R4OS 0.76.26](https://github.com/R4OSDev/r4os-distribution/releases/tag/v0.76.26).
`Artifacts/Qualification/0.76.26/lenovo.json` records the user acceptance;
`public-r4os.json` records the exact published asset hashes and source receipt.
The complete public Full ZIP passed the production-menu download acceptance
in 263.931 seconds (SMP4/8 GB), including independent cache verification,
unchanged other partitions and Terminal poweroff. The final report is
`Artifacts/Qualification/0.76.26/report.json`.


Remote-frame ownership (0.78.75)
-------------------------------
Recovery 0.1.56 imports the canonical R4DESK owner from Kernel 0.1.131.
Live copies and snapshot mutation use a nonblocking unwind-aware guard.
A short SMP state owner orders consumer epochs and completed revisions.
Last release invalidates the epoch immediately; any active copy retains
its storage, discards its stale result, and performs deferred cleanup at
owner exit. Raw maps require exactly one registered consumer; multiple
consumers use the existing bounded read-copy path. The bounded input queue
uses the same SMP state owner and counts full-queue rejection once.
The Menu artifact remains at 0.1.20.


Direct drawing and presentation ownership (0.78.76)
-------------------------------------------------
The public clear, rect, text and text_font operations now draw through
DisplayManager and mark actual display use. Rectangles and glyphs clip signed
coordinates; each text call holds one font-catalog view and uses the selected
or explicit font, UTF-8 scalars, glyph advances and foreground/background.
Hosted GUI targets and the separate boot/fatal console keep their ownership.

All productive DisplayManager writes share a preemptible, nonblocking
try-admission guard. An overlapping presentation returns unavailable without
pixels or a success fence. Legacy void drawing requires exclusive fullscreen
ownership and does not mark use on a collision. Completed statistics are
copied under the short SMP program-state owner. Pixel stores, including WC
stores, finish before published completion and before another CPU can write.
Each successful regions call advances one generation/fence; this represents
copy completion and does not promise VBlank synchronization or page flipping.

DisplayBlit admission and the in-flight registration reference are atomic
against cleanup. A call retains its copied descriptor, owner, generation and
name; cleanup refuses a busy registration. The synchronous callback runs
outside the short state owner, and its completion cannot affect a later
registration. The existing driver-manager shutdown sequence is retained.

Recovery 0.1.57 imports these canonical files from Kernel 0.1.132.
The Menu artifact remains at 0.1.20.

## Resident commit ownership (0.81.12)

The compatible Kernel owner change splits eager VM commits into at most
64-page sections and zeros private extents before publishing mappings. Heap
growth releases its metadata owner while the range transaction and task
unwind guard retain lifetime. Failed rollback keeps its exact mapped prefix
and private extent for retry. The frozen address windows, lazy VM contract,
resident Recovery preparation and imported runtime modules remain independent.
The transfer receipt records the canonical source, Recovery patch and hashes;
Recovery and its kernel advance together to 0.1.60.


Directory continuation (0.81.26)
-------------------------------
Recovery/Kernel 0.1.61 and Menu 0.1.23 use compatible caller-owned FAT/NTFS
continuation. Filesystem change publication and FAT cross-cluster LFN/growth
validation accompany the transfer. The R4SYS layout tail and required new
payloads are imported; unimplemented optional tail slots remain zero. Other
platform groups, scheduler/lifecycle policy and 39 imported modules stay pinned.
Menu rejects a failed/stale directory probe instead of treating it as EOF.
Owner commits, exact file hashes and the Recovery delta are recorded in
Provenance/owner-update-0.81.26.json. No public Recovery asset was published.
